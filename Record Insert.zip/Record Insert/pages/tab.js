// Salesforce object field configurations - This will be replaced by dynamic fetching
const FALLBACK_OBJECTS = {
    Lead: [
        { name: 'FirstName', label: 'First Name', type: 'text', required: false },
        { name: 'LastName', label: 'Last Name', type: 'text', required: true },
        { name: 'Company', label: 'Company', type: 'text', required: true },
        { name: 'Email', label: 'Email', type: 'email', required: true },
        { name: 'Phone', label: 'Phone', type: 'tel', required: false },
        { name: 'Status', label: 'Lead Status', type: 'select', required: true, options: [
            'Open - Not Contacted',
            'Working - Contacted',
            'Closed - Converted',
            'Closed - Not Converted'
        ]},
        { name: 'LeadSource', label: 'Lead Source', type: 'select', required: false, options: [
            'Web',
            'Phone Inquiry',
            'Partner Referral',
            'Purchased List',
            'Other'
        ]}
    ]
};

class SalesforceRecordManager {
    constructor() {
        this.entries = [];
        this.entryCounter = 0;
        this.selectedObject = '';
        this.selectedRecordType = '';
        this.isAuthenticated = false;
        this.availableObjects = [];
        this.objectFields = {};
        this.recordTypes = {};
        this.dropdownOpen = false;
        this.recordTypeDropdownOpen = false;
        this.recentRecords = [];
        this.sidebarOpen = false;
        this.currentEditingRecord = null;
        this.originalRecordData = {};
        this.selectedPermissionObject = '';
        this.selectedPermissionField = '';
        
        // Mock data for testing
        this.mockObjects = [
            { name: 'Account', label: 'Account', isCustom: false },
            { name: 'Contact', label: 'Contact', isCustom: false },
            { name: 'Lead', label: 'Lead', isCustom: false },
            { name: 'Opportunity', label: 'Opportunity', isCustom: false },
            { name: 'Case', label: 'Case', isCustom: false }
        ];
        
        this.mockFields = {
            Account: [
                { name: 'Name', label: 'Name', type: 'text' },
                { name: 'Type', label: 'Type', type: 'picklist' },
                { name: 'Industry', label: 'Industry', type: 'picklist' }
            ],
            Contact: [
                { name: 'FirstName', label: 'First Name', type: 'text' },
                { name: 'LastName', label: 'Last Name', type: 'text' },
                { name: 'Email', label: 'Email', type: 'email' }
            ],
            Lead: [
                { name: 'FirstName', label: 'First Name', type: 'text' },
                { name: 'LastName', label: 'Last Name', type: 'text' },
                { name: 'Company', label: 'Company', type: 'text' }
            ]
        };
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.setupFormValidation();
        this.checkAuthStatus();
        this.updateUI();
        this.startConnectivityMonitoring();
       // this.setupTabHandlers();
        this.initializeTabs();
    }

    initializeTabs() {
        const buttons = document.querySelectorAll(".tab-btn");
        const contents = document.querySelectorAll(".tab-content");

        buttons.forEach(btn => {
            btn.addEventListener("click", () => {
                // Remove active states from all buttons and contents
                buttons.forEach(b => b.classList.remove("active"));
                contents.forEach(c => c.classList.remove("active"));

                // Add active class to clicked button and its corresponding content
                btn.classList.add("active");
                document.getElementById(btn.dataset.tab).classList.add("active");

                // Initialize field permissions if tab2 is selected
                if (btn.dataset.tab === 'tab2') {
                    this.initializeFieldPermissions();
                }
            });
        });

        // Initialize field permissions if tab2 is initially active
        if (document.querySelector('.tab-btn[data-tab="tab2"]').classList.contains('active')) {
            this.initializeFieldPermissions();
        }
    }

    initializeFieldPermissions() {
        this.loadRecentRecordsFromStorage();

        // Initialize dropdown elements
        const objectSearch = document.getElementById('objectSearch');
        const fieldSearch = document.getElementById('fieldSearch');
        const objectList = document.getElementById('objectDropdownList');
        const fieldList = document.getElementById('fieldDropdownList');
        const objectTrigger = document.getElementById('objectDropdownTrigger');
        const fieldTrigger = document.getElementById('fieldDropdownTrigger');
        
        let selectedObject = null;
        let selectedField = null;

        // Function to fetch objects from Salesforce
        const fetchObjects = async (searchTerm = '') => {
            try {
                // TODO: Replace with actual Salesforce API call
                const response = await this.describeSObjects();
                const objects = response.filter(obj => 
                    obj.name.toLowerCase().includes(searchTerm.toLowerCase())
                );
                return objects;
            } catch (error) {
                console.error('Error fetching objects:', error);
                return [];
            }
        };

        // Function to fetch fields for selected object
        const fetchFields = async (objectName, searchTerm = '') => {
            try {
                // TODO: Replace with actual Salesforce API call
                const response = await this.describeObject(objectName);
                const fields = response.fields.filter(field => 
                    field.name.toLowerCase().includes(searchTerm.toLowerCase())
                );
                return fields;
            } catch (error) {
                console.error('Error fetching fields:', error);
                return [];
            }
        };

        // Function to fetch field permissions
        const fetchFieldPermissions = async (objectName, fieldName) => {
            try {
                // TODO: Replace with actual Salesforce API call
                const query = `SELECT SobjectType, Field, PermissionsRead, PermissionsEdit, Parent.IsCustom 
                             FROM FieldPermissions 
                             WHERE Field='${objectName}.${fieldName}'`;
                const response = await this.executeQuery(query);
                return response;
            } catch (error) {
                console.error('Error fetching permissions:', error);
                return [];
            }
        };

        // Function to update permissions table
        const updatePermissionsTable = (permissions) => {
            const tableBody = document.getElementById('permissionsTableBody');
            tableBody.innerHTML = permissions.map(perm => `
                <tr>
                    <td>${perm.SobjectType}</td>
                    <td>${perm.Field}</td>
                    <td>${perm.PermissionsRead ? '✓' : '✗'}</td>
                    <td>${perm.PermissionsEdit ? '✓' : '✗'}</td>
                    <td>${perm.Parent?.Name || '-'}</td>
                    <td>${perm.Parent?.IsCustom ? '✓' : '✗'}</td>
                </tr>
            `).join('');
        };

        // Initialize object dropdown
        objectSearch.addEventListener('input', async (e) => {
            const objects = await fetchObjects(e.target.value);
            objectList.innerHTML = objects.map(obj => `
                <div class="custom-dropdown-item" data-value="${obj.name}">
                    <div class="custom-object-label">${obj.label}</div>
                    <div class="custom-object-description">${obj.isCustom ? 'Custom Object' : 'Standard Object'}</div>
                </div>
            `).join('');
        });

        // Initialize field dropdown
        fieldSearch.addEventListener('input', async (e) => {
            if (!selectedObject) return;
            const fields = await fetchFields(selectedObject, e.target.value);
            fieldList.innerHTML = fields.map(field => `
                <div class="custom-dropdown-item" data-value="${field.name}">
                    <div class="custom-object-label">${field.label}</div>
                    <div class="custom-object-description">${field.type}</div>
                </div>
            `).join('');
        });

        // Handle object selection
        objectList.addEventListener('click', async (e) => {
            const item = e.target.closest('.custom-dropdown-item');
            if (!item) return;

            selectedObject = item.dataset.value;
            document.getElementById('objectDropdownText').textContent = item.textContent;
            document.getElementById('objectDropdownContent').classList.remove('active');
            objectTrigger.classList.remove('active');

            // Reset field selection
            selectedField = null;
            document.getElementById('fieldDropdownText').textContent = 'Select Field';
            fieldList.innerHTML = '';

            // Fetch fields for selected object
            const fields = await fetchFields(selectedObject);
            fieldList.innerHTML = fields.map(field => `
                <div class="custom-dropdown-item" data-value="${field.name}">${field.label}</div>
            `).join('');
        });

        // Handle field selection
        fieldList.addEventListener('click', async (e) => {
            const item = e.target.closest('.custom-dropdown-item');
            if (!item) return;

            selectedField = item.dataset.value;
            document.getElementById('fieldDropdownText').textContent = item.textContent;
            document.getElementById('fieldDropdownContent').classList.remove('active');
            fieldTrigger.classList.remove('active');

            // Fetch and display permissions
            if (selectedObject && selectedField) {
                const permissions = await fetchFieldPermissions(selectedObject, selectedField);
                updatePermissionsTable(permissions);
            }
        });

        // Toggle dropdowns
        objectTrigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const content = document.getElementById('objectDropdownContent');
            const fieldContent = document.getElementById('fieldDropdownContent');
            const fieldTrigger = document.getElementById('fieldDropdownTrigger');
            
            // Close field dropdown if open
            fieldContent.classList.remove('active');
            fieldTrigger.classList.remove('active');
            
            // Toggle object dropdown
            objectTrigger.classList.toggle('active');
            content.classList.toggle('active');
        });

        fieldTrigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const content = document.getElementById('fieldDropdownContent');
            const objectContent = document.getElementById('objectDropdownContent');
            
            // Close object dropdown if open
            objectContent.classList.remove('active');
            objectTrigger.classList.remove('active');
            
            // Toggle field dropdown
            fieldTrigger.classList.toggle('active');
            content.classList.toggle('active');
        });

        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.custom-dropdown-wrapper')) {
                const objectContent = document.getElementById('objectDropdownContent');
                const fieldContent = document.getElementById('fieldDropdownContent');
                const objectTrigger = document.getElementById('objectDropdownTrigger');
                const fieldTrigger = document.getElementById('fieldDropdownTrigger');
                
                objectContent.classList.remove('active');
                objectTrigger.classList.remove('active');
                fieldContent.classList.remove('active');
                fieldTrigger.classList.remove('active');
            }
        });

        // Initial objects load
        fetchObjects().then(objects => {
            objectList.innerHTML = objects.map(obj => `
                <div class="custom-dropdown-item" data-value="${obj.name}">${obj.label}</div>
            `).join('');
        });
    }
    
    
    startConnectivityMonitoring() {
        // Check connectivity every 30 seconds
        setInterval(() => {
            this.checkConnectivity();
        }, 30000);
    }
    
    // Salesforce API Methods
    async describeSObjects() {
        // For now, return mock data
        return this.mockObjects;
    }

    async describeObject(objectName) {
        // For now, return mock data
        return {
            name: objectName,
            fields: this.mockFields[objectName] || []
        };
    }

    async executeQuery(query) {
        // For now, return mock data
        return [
            {
                SobjectType: 'Account',
                Field: 'Name',
                PermissionsRead: true,
                PermissionsEdit: true,
                Parent: { Name: 'System Administrator', IsCustom: false }
            }
        ];
    }

    async checkConnectivity() {
        try {
            const result = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
            
            if (!result.sfToken || !result.sfInstanceUrl) {
                this.isAuthenticated = false;
                this.updateConnectivityIndicator('disconnected');
                return;
            }
            
            // Quick connectivity test
            const response = await fetch(`${result.sfInstanceUrl}/services/data/v57.0/limits/`, {
                headers: {
                    'Authorization': `Bearer ${result.sfToken}`,
                    'Content-Type': 'application/json'
                },
                method: 'GET',
                timeout: 5000
            });
            
            if (response.ok) {
                this.isAuthenticated = true;
                this.updateConnectivityIndicator('connected');
            } else {
                this.isAuthenticated = false;
                this.updateConnectivityIndicator('disconnected');
            }
            
        } catch (error) {
            console.log('Connectivity check failed:', error);
            this.isAuthenticated = false;
            this.updateConnectivityIndicator('disconnected');
        }
    }
    
    bindEvents() {
        const customDropdownTrigger = document.getElementById('customDropdownTrigger');
        const customDropdownTriggerPerm = document.getElementById('customDropdownTriggerPerm');
        const customSearchInput = document.getElementById('customSearchInput');
        const customSearchInputPerm = document.getElementById('customSearchInputPerm');
        const recordTypeDropdownTrigger = document.getElementById('recordTypeDropdownTrigger');
        const recordTypeSearchInput = document.getElementById('recordTypeSearchInput');
        const addEntryBtn = document.getElementById('addEntry');
        const refreshDataBtn = document.getElementById('refreshData');
        const submitAllBtn = document.getElementById('submitAll');
        const clearAllBtn = document.getElementById('clearAll');
        
        // Custom dropdown toggle
        if (customDropdownTrigger) {
            customDropdownTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleCustomDropdown();
            });
        }

        // Permission dropdown toggle
        if (customDropdownTriggerPerm) {
            customDropdownTriggerPerm.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleCustomDropdownPerm();
            });
        }
        
        // Record Type dropdown toggle
        if (recordTypeDropdownTrigger) {
            recordTypeDropdownTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleRecordTypeDropdown();
            });
        }
        
        // Search functionality
        if (customSearchInput) {
            customSearchInput.addEventListener('input', (e) => {
                const items = document.querySelectorAll('#customDropdownList .custom-dropdown-item');
                this.filterItems(e.target.value, items);
            });
        }

        // Permission search functionality
        if (customSearchInputPerm) {
            customSearchInputPerm.addEventListener('input', (e) => {
                const items = document.querySelectorAll('#customDropdownListPerm .custom-dropdown-item');
                this.filterItems(e.target.value, items);
            });
        }
        
        // Record Type search functionality
        if (recordTypeSearchInput) {
            recordTypeSearchInput.addEventListener('input', (e) => {
                this.filterRecordTypes(e.target.value);
            });
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.custom-dropdown')) {
                this.closeCustomDropdown();
                this.closeCustomDropdownPerm();
                this.closeRecordTypeDropdown();
            }
        });
        
        // Prevent dropdown close when clicking inside
        const customDropdownContent = document.getElementById('customDropdownContent');
        if (customDropdownContent) {
            customDropdownContent.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
        
        // Prevent record type dropdown close when clicking inside
        const recordTypeDropdownContent = document.getElementById('recordTypeDropdownContent');
        if (recordTypeDropdownContent) {
            recordTypeDropdownContent.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
        
        addEntryBtn.addEventListener('click', () => {
            this.addNewEntry();
        });
        
        refreshDataBtn.addEventListener('click', () => {
            this.refreshData();
        });
        
        submitAllBtn.addEventListener('click', () => {
            this.submitAllRecords();
        });
        
        clearAllBtn.addEventListener('click', () => {
            this.clearAllEntries();
        });
        
        // Connectivity indicator click to refresh connection
        const connectivityIndicator = document.getElementById('connectivityIndicator');
        if (connectivityIndicator) {
            connectivityIndicator.addEventListener('click', () => {
                this.checkAuthStatus();
            });
        }

        // Sidebar event handlers
        const closeSidebar = document.getElementById('closeSidebar');
        if (closeSidebar) {
            closeSidebar.addEventListener('click', () => {
                this.closeSidebar();
            });
        }

        const clearRecentRecords = document.getElementById('clearRecentRecords');
        if (clearRecentRecords) {
            clearRecentRecords.addEventListener('click', () => {
                this.clearRecentRecords();
            });
        }

        // Floating sidebar toggle button
        const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
        if (sidebarToggleBtn) {
            sidebarToggleBtn.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }

        // Record details modal event handlers
        const recordDetailsClose = document.getElementById('recordDetailsClose');
        if (recordDetailsClose) {
            recordDetailsClose.addEventListener('click', () => {
                this.closeRecordDetailsModal();
            });
        }

        const recordDetailsCancel = document.getElementById('recordDetailsCancel');
        if (recordDetailsCancel) {
            recordDetailsCancel.addEventListener('click', () => {
                this.closeRecordDetailsModal();
            });
        }

        const recordDetailsEdit = document.getElementById('recordDetailsEdit');
        if (recordDetailsEdit) {
            recordDetailsEdit.addEventListener('click', () => {
                this.enableRecordEditing();
            });
        }

        const recordDetailsSave = document.getElementById('recordDetailsSave');
        if (recordDetailsSave) {
            recordDetailsSave.addEventListener('click', () => {
                this.saveRecordChanges();
            });
        }

        // Close modal when clicking outside
        const recordDetailsModal = document.getElementById('recordDetailsModal');
        if (recordDetailsModal) {
            recordDetailsModal.addEventListener('click', (e) => {
                if (e.target === recordDetailsModal) {
                    this.closeRecordDetailsModal();
                }
            });
        }

        // Input Fields Section Event Handlers
        this.bindInputFieldsEvents();

        // Delegate events for entry actions
        document.addEventListener('click', (e) => {
            // Check if it's an entry header click (for toggling)
            const entryHeader = e.target.closest('.entry-header');
            if (entryHeader) {
                // Don't trigger if clicking on action buttons
                if (!e.target.closest('.entry-actions')) {
                    const entryCard = entryHeader.closest('.entry-card');
                    const entryId = entryCard?.dataset.entryId;
                    if (entryId) {
                        this.toggleEntry(entryId);
                        return;
                    }
                }
            }
            
            // Handle action button clicks (including SVG elements inside buttons)
            const actionButton = e.target.closest('[data-action]');
            if (!actionButton) return;
            
            const action = actionButton.dataset.action;
            const entryCard = actionButton.closest('.entry-card');
            const entryId = entryCard?.dataset.entryId;
            
            if (!entryId) return;
            
            e.preventDefault();
            e.stopPropagation();
            
            switch (action) {
                case 'toggle':
                    this.toggleEntry(entryId);
                    break;
                case 'delete':
                    this.deleteEntry(entryId);
                    break;
                case 'submit':
                    this.submitSingleRecord(entryId);
                    break;
                case 'reset':
                    this.resetEntry(entryId);
                    break;
            }
        });
    }

    bindInputFieldsEvents() {
        const objectTypeDropdownTrigger = document.getElementById('objectTypeDropdownTrigger');
        const objectTypeSearchInput = document.getElementById('objectTypeSearchInput');
        const addNewEntryInputBtn = document.getElementById('addNewEntryInput');
        const refreshDataInputBtn = document.getElementById('refreshDataInput');
        
        // Input dropdown toggle
        if (objectTypeDropdownTrigger) {
            objectTypeDropdownTrigger.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleInputDropdown();
            });
        }
        
        // Input search functionality
        if (objectTypeSearchInput) {
            objectTypeSearchInput.addEventListener('input', (e) => {
                this.filterInputObjects(e.target.value);
            });
        }
        
        // Close input dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.input-dropdown')) {
                this.closeInputDropdown();
            }
        });
        
        // Prevent input dropdown close when clicking inside
        const objectTypeDropdownContent = document.getElementById('objectTypeDropdownContent');
        if (objectTypeDropdownContent) {
            objectTypeDropdownContent.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
        
        // Input buttons
        if (addNewEntryInputBtn) {
            addNewEntryInputBtn.addEventListener('click', () => {
                this.addNewEntry();
            });
        }
        
        if (refreshDataInputBtn) {
            refreshDataInputBtn.addEventListener('click', () => {
                this.refreshData();
            });
        }
    }
    
    toggleInputDropdown() {
        const trigger = document.getElementById('objectTypeDropdownTrigger');
        const content = document.getElementById('objectTypeDropdownContent');
        
        if (content.classList.contains('show')) {
            this.closeInputDropdown();
        } else {
            this.openInputDropdown();
        }
    }
    
    openInputDropdown() {
        const trigger = document.getElementById('objectTypeDropdownTrigger');
        const content = document.getElementById('objectTypeDropdownContent');
        
        trigger.classList.add('active');
        content.classList.add('show');
        
        // Load objects if not already loaded
        if (this.availableObjects.length === 0) {
            this.loadAvailableObjects('input');
        } else {
            this.populateInputDropdown(this.availableObjects);
        }
    }
    
    closeInputDropdown() {
        const trigger = document.getElementById('objectTypeDropdownTrigger');
        const content = document.getElementById('objectTypeDropdownContent');
        
        if (trigger) trigger.classList.remove('active');
        if (content) content.classList.remove('show');
    }
    
    filterInputObjects(searchTerm) {
        const filteredObjects = this.availableObjects.filter(obj => 
            obj.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
            obj.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        this.populateInputDropdown(filteredObjects);
    }
    
    populateInputDropdown(objects) {
        const list = document.getElementById('objectTypeDropdownList');
        if (!list) return;
        
        if (objects.length === 0) {
            list.innerHTML = '<div class="input-dropdown-item no-results">No objects found</div>';
            return;
        }
        
        list.innerHTML = objects.map(obj => `
            <div class="input-dropdown-item" data-value="${obj.name}" data-label="${obj.label}">
                <div class="input-dropdown-item-content">
                    <span class="input-dropdown-item-label">${obj.label}</span>
                    <span class="input-dropdown-item-name">${obj.name}</span>
                </div>
            </div>
        `).join('');
        
        // Add click handlers for input dropdown items
        list.querySelectorAll('.input-dropdown-item').forEach(item => {
            item.addEventListener('click', () => {
                const value = item.dataset.value;
                const label = item.dataset.label;
                this.selectInputObject(value, label);
            });
        });
    }
    
    selectInputObject(objectName, objectLabel) {
        const dropdownText = document.getElementById('objectTypeDropdownText');
        const addButton = document.getElementById('addNewEntryInput');
        
        if (dropdownText) {
            dropdownText.textContent = objectLabel;
            dropdownText.classList.remove('placeholder');
        }
        
        if (addButton) {
            addButton.disabled = false;
        }
        
        this.selectedObject = objectName;
        this.closeInputDropdown();
        
        // Also update the main dropdown to keep them in sync
        this.syncMainDropdown(objectName, objectLabel);
    }

    async loadAvailableObjects(target = 'main') {
        const listElement = target === 'input' ? 
            document.getElementById('objectTypeDropdownList') : 
            document.getElementById('customDropdownList');
            
        if (listElement) {
            listElement.innerHTML = `
                <div class="custom-dropdown-loading">
                    <div class="loading-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <span>Loading objects...</span>
                </div>
            `;
        }
        
        try {
            if (this.isAuthenticated) {
                // Try to fetch objects from Salesforce
                const objects = await this.fetchSalesforceObjects();
                this.availableObjects = objects;
            } else {
                // Use fallback objects
                this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                    name: key,
                    label: key,
                    description: `Create ${key} records`,
                    icon: this.getObjectIcon(key)
                }));
            }
            
            if (target === 'input') {
                this.populateInputDropdown(this.availableObjects);
            } else {
                this.renderCustomObjectOptions();
            }
            
        } catch (error) {
            console.error('Error loading objects:', error);
            // Fall back to static objects
            this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                name: key,
                label: key,
                description: `Create ${key} records`,
                icon: this.getObjectIcon(key)
            }));
            
            if (target === 'input') {
                this.populateInputDropdown(this.availableObjects);
            } else {
                this.renderCustomObjectOptions();
            }
        }
    }
    
    syncMainDropdown(objectName, objectLabel) {
        const mainDropdownText = document.getElementById('customDropdownText');
        const mainAddButton = document.getElementById('addEntry');
        
        if (mainDropdownText) {
            mainDropdownText.textContent = objectLabel;
        }
        
        if (mainAddButton) {
            mainAddButton.disabled = false;
        }
    }
    
    toggleCustomDropdown() {
        if (this.dropdownOpen) {
            this.closeCustomDropdown();
        } else {
            this.openCustomDropdown();
        }
    }

    toggleCustomDropdownPerm() {
        if (this.dropdownOpen) {
            this.closeCustomDropdownPerm();
        } else {
            this.openCustomDropdownPerm();
        }
    }

    // Removed filterCustomObjectsPerm as it's replaced by filterItems
    
    openCustomDropdown() {
        const trigger = document.getElementById('customDropdownTrigger');
        const content = document.getElementById('customDropdownContent');
        
        if (trigger) trigger.classList.add('active');
        if (content) content.classList.add('show');
        this.dropdownOpen = true;
        
        // Focus search input
        setTimeout(() => {
            const searchInput = document.getElementById('customSearchInput');
            if (searchInput) searchInput.focus();
        }, 100);
        
        // Load objects if not already loaded
        if (this.availableObjects.length === 0) {
            this.loadSalesforceObjects();
        }
    }
    
    openCustomDropdownPerm() {
        const trigger = document.getElementById('customDropdownTriggerPerm');
        const content = document.getElementById('customDropdownContentPerm');

        if (trigger) trigger.classList.add('active');
        if (content) content.classList.add('show');
        this.dropdownOpen = true;
        
        // Focus search input
        setTimeout(() => {
            const searchInput = document.getElementById('customSearchInputPerm');
            if (searchInput) searchInput.focus();
        }, 100);
        
        // Load objects if not already loaded
        if (this.availableObjects.length === 0) {
            this.loadSalesforceObjectsPerm();
        }
    }
    closeCustomDropdown() {
        const trigger = document.getElementById('customDropdownTrigger');
        const content = document.getElementById('customDropdownContent');
        
        if (trigger) trigger.classList.remove('active');
        if (content) content.classList.remove('show');
        this.dropdownOpen = false;
        
        // Clear search
        const searchInput = document.getElementById('customSearchInput');
        if (searchInput) {
            searchInput.value = '';
            const items = document.querySelectorAll('#customDropdownList .custom-dropdown-item');
            this.filterItems('', items);
        }
    }

    closeCustomDropdownPerm() {
        const trigger = document.getElementById('customDropdownTriggerPerm');
        const content = document.getElementById('customDropdownContentPerm');

        if (trigger) trigger.classList.remove('active');
        if (content) content.classList.remove('show');
        this.dropdownOpen = false;
        
        // Clear search
        const searchInput = document.getElementById('customSearchInputPerm');
        if (searchInput) {
            searchInput.value = '';
            const items = document.querySelectorAll('#customDropdownListPerm .custom-dropdown-item');
            this.filterItems('', items);
        }
    }
    
    // Record Type Dropdown Methods
    toggleRecordTypeDropdown() {
        if (this.recordTypeDropdownOpen) {
            this.closeRecordTypeDropdown();
        } else {
            this.openRecordTypeDropdown();
        }
    }
    
    openRecordTypeDropdown() {
        const trigger = document.getElementById('recordTypeDropdownTrigger');
        const content = document.getElementById('recordTypeDropdownContent');
        
        if (trigger) trigger.classList.add('active');
        if (content) content.classList.add('show');
        this.recordTypeDropdownOpen = true;
        
        // Focus search input
        setTimeout(() => {
            const searchInput = document.getElementById('recordTypeSearchInput');
            if (searchInput) searchInput.focus();
        }, 100);
        
        // Load record types for selected object
        if (this.selectedObject) {
            this.loadRecordTypes(this.selectedObject);
        } else {
            this.renderNoRecordTypes();
        }
    }
    
    closeRecordTypeDropdown() {
        const trigger = document.getElementById('recordTypeDropdownTrigger');
        const content = document.getElementById('recordTypeDropdownContent');
        
        if (trigger) trigger.classList.remove('active');
        if (content) content.classList.remove('show');
        this.recordTypeDropdownOpen = false;
        
        // Clear search
        const searchInput = document.getElementById('recordTypeSearchInput');
        if (searchInput) {
            searchInput.value = '';
            this.filterRecordTypes('');
        }
    }
    
    filterRecordTypes(searchTerm) {
        const items = document.querySelectorAll('.record-type-dropdown-item');
        const term = searchTerm.toLowerCase();
        
        items.forEach(item => {
            const label = item.querySelector('.record-type-label');
            const description = item.querySelector('.record-type-description');
            if (label && description) {
                const labelText = label.textContent.toLowerCase();
                const descText = description.textContent.toLowerCase();
                const matches = labelText.includes(term) || descText.includes(term);
                
                item.style.display = matches ? 'flex' : 'none';
            }
        });
    }
    
    async loadRecordTypes(objectName) {
        const container = document.getElementById('recordTypeDropdownList');
        if (!container) return;
        
        container.innerHTML = `
            <div class="custom-dropdown-loading">
                <div class="loading-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <span>Loading record types...</span>
            </div>
        `;
        
        try {
            if (this.isAuthenticated) {
                // Fetch record types from Salesforce
                const recordTypes = await this.fetchRecordTypes(objectName);
                this.recordTypes[objectName] = recordTypes;
            } else {
                // Use fallback - default record type
                this.recordTypes[objectName] = [
                    { id: '012000000000000AAA', name: 'Master', label: 'Master', isDefault: true }
                ];
            }
            
            this.renderRecordTypes(this.recordTypes[objectName]);
            
        } catch (error) {
            console.error('Error loading record types:', error);
            // Fall back to default record type
            this.recordTypes[objectName] = [
                { id: '012000000000000AAA', name: 'Master', label: 'Master', isDefault: true }
            ];
            this.renderRecordTypes(this.recordTypes[objectName]);
        }
    }
    
    async fetchRecordTypes(objectName) {
        const { sfToken, sfInstanceUrl } = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
        
        const response = await fetch(`${sfInstanceUrl}/services/data/v59.0/sobjects/${objectName}/describe/`, {
            headers: {
                'Authorization': `Bearer ${sfToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch record types');
        }
        
        const data = await response.json();
        const recordTypes = data.recordTypeInfos || [];
        
        return recordTypes
            .filter(rt => rt.available)
            .map(rt => ({
                id: rt.recordTypeId,
                name: rt.name,
                label: rt.name,
                isDefault: rt.defaultRecordTypeMapping
            }))
            .sort((a, b) => {
                // Sort default first, then alphabetically
                if (a.isDefault && !b.isDefault) return -1;
                if (!a.isDefault && b.isDefault) return 1;
                return a.label.localeCompare(b.label);
            });
    }
    
    renderRecordTypes(recordTypes) {
        const container = document.getElementById('recordTypeDropdownList');
        if (!container) return;
        
        if (recordTypes.length === 0) {
            container.innerHTML = `
                <div class="custom-dropdown-loading">
                    <span>No record types available</span>
                </div>
            `;
            return;
        }
        
        const html = recordTypes.map(rt => `
            <div class="record-type-dropdown-item custom-dropdown-item" data-record-type-id="${rt.id}" data-record-type-name="${rt.name}">
                <div class="record-type-icon custom-object-icon" style="background-color: #4fc3f7">
                    ${rt.label.charAt(0)}
                </div>
                <div class="record-type-info custom-object-info">
                    <div class="record-type-label custom-object-label">${rt.label}${rt.isDefault ? ' (Default)' : ''}</div>
                    <div class="record-type-description custom-object-description">Record Type for ${this.selectedObject}</div>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
        
        // Add click handlers
        container.querySelectorAll('.record-type-dropdown-item').forEach(option => {
            option.addEventListener('click', (e) => {
                const recordTypeId = e.currentTarget.dataset.recordTypeId;
                const recordTypeName = e.currentTarget.dataset.recordTypeName;
                this.selectRecordType(recordTypeId, recordTypeName);
            });
        });
    }
    
    renderNoRecordTypes() {
        const container = document.getElementById('recordTypeDropdownList');
        if (!container) return;
        
        container.innerHTML = `
            <div class="custom-dropdown-loading">
                <span>Please select an object first</span>
            </div>
        `;
    }
    
    selectRecordType(recordTypeId, recordTypeName) {
        this.selectedRecordType = recordTypeId;
        
        // Update dropdown text
        const dropdownText = document.getElementById('recordTypeDropdownText');
        if (dropdownText) {
            dropdownText.textContent = recordTypeName;
        }
        
        // Update UI
        const items = document.querySelectorAll('.record-type-dropdown-item');
        items.forEach(item => {
            item.classList.remove('selected');
            if (item.dataset.recordTypeId === recordTypeId) {
                item.classList.add('selected');
            }
        });
        
        // Close dropdown
        this.closeRecordTypeDropdown();
        
        // Update entry creation button state
        this.updateUI();
    }
    
    async loadSalesforceObjects() {
        const optionsContainer = document.getElementById('customDropdownList');
        if (optionsContainer) {
            optionsContainer.innerHTML = `
                <div class="custom-dropdown-loading">
                    <div class="loading-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <span>Loading objects...</span>
                </div>
            `;
        }
        
        try {
            if (this.isAuthenticated) {
                // Try to fetch objects from Salesforce
                const objects = await this.fetchSalesforceObjects();
                this.availableObjects = objects;
            } else {
                // Use fallback objects
                this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                    name: key,
                    label: key,
                    description: `Create ${key} records`,
                    icon: this.getObjectIcon(key)
                }));
            }
            
            this.renderCustomObjectOptions();
            
        } catch (error) {
            console.error('Error loading objects:', error);
            // Fall back to static objects
            this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                name: key,
                label: key,
                description: `Create ${key} records`,
                icon: this.getObjectIcon(key)
            }));
            this.renderCustomObjectOptions();
        }
    }
    
    async loadSalesforceObjectsPerm() {
        const optionsContainer = document.getElementById('customDropdownListPerm');
        if (optionsContainer) {
            optionsContainer.innerHTML = `
                <div class="custom-dropdown-loading">
                    <div class="loading-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <span>Loading objects...</span>
                </div>
            `;
        }
        
        try {
            if (this.isAuthenticated) {
                // Try to fetch objects from Salesforce
                const objects = await this.fetchSalesforceObjects();
                this.availableObjects = objects;
            } else {
                // Use fallback objects
                this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                    name: key,
                    label: key,
                    description: `Check ${key} field permissions`,
                    icon: this.getObjectIcon(key)
                }));
            }
            
            this.renderCustomObjectOptionsPerm();
            
        } catch (error) {
            console.error('Error loading objects:', error);
            // Fall back to static objects
            this.availableObjects = Object.keys(FALLBACK_OBJECTS).map(key => ({
                name: key,
                label: key,
                description: `Check ${key} field permissions`,
                icon: this.getObjectIcon(key)
            }));
            this.renderCustomObjectOptionsPerm();
        }
    }

    renderCustomObjectOptionsPerm() {
        const container = document.getElementById('customDropdownListPerm');
        if (!container) return;
        
        if (this.availableObjects.length === 0) {
            container.innerHTML = `
                <div class="custom-dropdown-loading">
                    <span>No objects available</span>
                </div>
            `;
            return;
        }
        
        const html = this.availableObjects.map(obj => `
            <div class="custom-dropdown-item" data-object="${obj.name}">
                <div class="custom-object-icon" style="background-color: ${obj.icon}">
                    ${obj.label.charAt(0)}
                </div>
                <div class="custom-object-info">
                    <div class="custom-object-label">${obj.label}</div>
                    <div class="custom-object-description">${obj.description}</div>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
        
        // Add click handlers
        container.querySelectorAll('.custom-dropdown-item').forEach(option => {
            option.addEventListener('click', (e) => {
                const objectName = e.currentTarget.dataset.object;
                this.selectPermissionObject(objectName);
            });
        });
    }

    selectPermissionObject(objectName) {
        this.selectedPermissionObject = objectName;
        
        // Update dropdown text
        const dropdownText = document.getElementById('customDropdownTextPerm');
        if (dropdownText) {
            const selectedObj = this.availableObjects.find(obj => obj.name === objectName);
            dropdownText.textContent = selectedObj ? selectedObj.label : objectName;
        }
        
        // Close dropdown and update UI
        this.closeCustomDropdownPerm();
        
        // Load fields for the selected object
        this.loadObjectFields(objectName);
    }
    
    async fetchSalesforceObjects() {
        const { sfToken, sfInstanceUrl } = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
        
        const response = await fetch(`${sfInstanceUrl}/services/data/v59.0/sobjects/`, {
            headers: {
                'Authorization': `Bearer ${sfToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch objects');
        }
        
        const data = await response.json();
        return data.sobjects
            .filter(obj => obj.createable && obj.queryable && !obj.name.endsWith('__History'))
            .map(obj => ({
                name: obj.name,
                label: obj.label,
                description: `Create ${obj.label} records`,
                icon: this.getObjectIcon(obj.name)
            }))
            .sort((a, b) => a.label.localeCompare(b.label));
    }
    
    getObjectIcon(objectName) {
        const icons = {
            'Lead': '#ff6b35',
            'Contact': '#4fc3f7',
            'Account': '#66bb6a',
            'Opportunity': '#ffa726',
            'Case': '#ef5350',
            'Task': '#ab47bc',
            'Event': '#5c6bc0'
        };
        return icons[objectName] || '#78909c';
    }
    
    renderObjectOptions() {
        const container = document.getElementById('objectOptions');
        
        if (this.availableObjects.length === 0) {
            container.innerHTML = '<div class="loading-spinner">No objects available</div>';
            return;
        }
        
        const html = this.availableObjects.map(obj => `
            <div class="dropdown-option" data-object="${obj.name}">
                <div class="object-icon" style="background-color: ${obj.icon}">
                    ${obj.label.charAt(0)}
                </div>
                <div class="object-info">
                    <div class="object-label">${obj.label}</div>
                    <div class="object-description">${obj.description}</div>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
        
        // Add click handlers
        container.querySelectorAll('.dropdown-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const objectName = e.currentTarget.dataset.object;
                this.selectObject(objectName);
            });
        });
    }
    
    filterObjects(searchTerm) {
        const options = document.querySelectorAll('.dropdown-option');
        this.filterItems(searchTerm, options);
    }
    
    async selectObject(objectName) {
        this.selectedObject = objectName;
        
        // Update button text with animation
        const selectorText = document.querySelector('.selector-text');
        const selectedObj = this.availableObjects.find(obj => obj.name === objectName);
        const newText = selectedObj ? selectedObj.label : objectName;
        
        // Add update animation
        selectorText.style.opacity = '0.5';
        selectorText.style.transform = 'translateX(-5px)';
        
        setTimeout(() => {
            selectorText.textContent = newText;
            selectorText.style.opacity = '1';
            selectorText.style.transform = 'translateX(0)';
        }, 150);
        
        // Update header title
        //this.updateHeaderTitle();
        
        // Close dropdown
        this.closeDropdown();
        
        // Load field metadata for this object
        await this.loadObjectFields(objectName);
        
        // Update UI
        this.updateUI();
        
        // Add success animation to the selector button
        const selectorBtn = document.getElementById('objectSelector');
        selectorBtn.classList.add('success-animation');
        setTimeout(() => {
            selectorBtn.classList.remove('success-animation');
        }, 600);
    }
    
    renderCustomObjectOptions() {
        const container = document.getElementById('customDropdownList');
        
        if (!container) return;
        
        if (this.availableObjects.length === 0) {
            container.innerHTML = `
                <div class="custom-dropdown-loading">
                    <span>No objects available</span>
                </div>
            `;
            return;
        }
        
        const html = this.availableObjects.map(obj => `
            <div class="custom-dropdown-item" data-object="${obj.name}">
                <div class="custom-object-icon" style="background-color: ${obj.icon}">
                    ${obj.label.charAt(0)}
                </div>
                <div class="custom-object-info">
                    <div class="custom-object-label">${obj.label}</div>
                    <div class="custom-object-description">${obj.description}</div>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
        
        // Add click handlers
        container.querySelectorAll('.custom-dropdown-item').forEach(option => {
            option.addEventListener('click', (e) => {
                const objectName = e.currentTarget.dataset.object;
                this.selectCustomObject(objectName);
            });
        });
    }
    
    async selectCustomObject(objectName) {
        const selectedObject = this.availableObjects.find(obj => obj.name === objectName);
        if (!selectedObject) return;
        
        // Update dropdown text
        const dropdownText = document.getElementById('customDropdownText');
        if (dropdownText) {
            dropdownText.textContent = selectedObject.label;
        }
        
        // Update selected state
        this.selectedObject = objectName;
        
        // Reset record type selection
        this.selectedRecordType = '';
        const recordTypeDropdownText = document.getElementById('recordTypeDropdownText');
        if (recordTypeDropdownText) {
            recordTypeDropdownText.textContent = 'Select Record Type';
        }
        
        // Update UI
        const items = document.querySelectorAll('.custom-dropdown-item');
        items.forEach(item => {
            item.classList.remove('selected');
            if (item.dataset.object === objectName) {
                item.classList.add('selected');
            }
        });
        
        // Close dropdown
        this.closeCustomDropdown();
        
        // Load fields for selected object
        await this.loadObjectFields(objectName);
        
        // Load record types for selected object
        await this.loadRecordTypes(objectName);
        
        // Auto-select default record type if available
        const recordTypes = this.recordTypes[objectName] || [];
        const defaultRecordType = recordTypes.find(rt => rt.isDefault);
        if (defaultRecordType) {
            this.selectRecordType(defaultRecordType.id, defaultRecordType.label);
        } else if (recordTypes.length === 1) {
            // If only one record type, auto-select it
            this.selectRecordType(recordTypes[0].id, recordTypes[0].label);
        }
        
        // Enable add entry button only if record type is selected
        const addEntryBtn = document.getElementById('addEntry');
        if (addEntryBtn) {
            addEntryBtn.disabled = !this.selectedRecordType;
        }
        
        // Update header title
        //this.updateHeaderTitle();
        
        this.updateUI();
    }
    
    filterItems(searchTerm, items) {
        const term = searchTerm.toLowerCase();
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            const matches = text.includes(term);
            item.style.display = matches ? 'flex' : 'none';
        });
    }
    
    // updateHeaderTitle() {
    //     const headerTitle = document.getElementById('headerTitle');
    //     if (this.selectedObject) {
    //         const selectedObj = this.availableObjects.find(obj => obj.name === this.selectedObject);
    //         const objectLabel = selectedObj ? selectedObj.label : this.selectedObject;
    //         headerTitle.textContent = `${objectLabel} Record Insert`;
            
    //         // Add animation
    //         headerTitle.style.transform = 'scale(1.05)';
    //         setTimeout(() => {
    //             headerTitle.style.transform = 'scale(1)';
    //         }, 200);
    //     } else {
    //         headerTitle.textContent = 'Salesforce Record Insert';
    //     }
    // }
    
    async loadObjectFields(objectName) {
        // Check if we already have the fields
        if (this.objectFields[objectName]) {
            return;
        }
        
        try {
            if (this.isAuthenticated) {
                // Fetch from Salesforce
                const fields = await this.fetchObjectFields(objectName);
                this.objectFields[objectName] = fields;
            } else {
                // Use fallback
                this.objectFields[objectName] = FALLBACK_OBJECTS[objectName] || [];
            }
        } catch (error) {
            console.error('Error loading fields:', error);
            // Use fallback
            this.objectFields[objectName] = FALLBACK_OBJECTS[objectName] || [];
        }
    }
    
    async fetchObjectFields(objectName) {
        const { sfToken, sfInstanceUrl } = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
        
        const response = await fetch(`${sfInstanceUrl}/services/data/v59.0/sobjects/${objectName}/describe/`, {
            headers: {
                'Authorization': `Bearer ${sfToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch object fields');
        }
        
        const data = await response.json();
        return data.fields
            .filter(field => field.createable && !field.calculated)
            .map(field => ({
                name: field.name,
                label: field.label,
                type: this.mapSalesforceType(field.type),
                required: !field.nillable && !field.defaultedOnCreate,
                options: field.picklistValues ? field.picklistValues.map(pv => pv.value) : null
            }))
            .sort((a, b) => {
                // Sort required fields first, then alphabetically
                if (a.required && !b.required) return -1;
                if (!a.required && b.required) return 1;
                return a.label.localeCompare(b.label);
            });
    }
    
    mapSalesforceType(sfType) {
        const typeMap = {
            'string': 'text',
            'email': 'email',
            'phone': 'tel',
            'url': 'url',
            'textarea': 'textarea',
            'picklist': 'select',
            'multipicklist': 'select',
            'boolean': 'checkbox',
            'date': 'date',
            'datetime': 'datetime-local',
            'currency': 'number',
            'double': 'number',
            'int': 'number',
            'percent': 'number'
        };
        return typeMap[sfType.toLowerCase()] || 'text';
    }
    
    async checkAuthStatus() {
        try {
            // Set initial connecting state
            this.updateConnectivityIndicator('connecting');
            
            // First check if we have stored credentials
            const result = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
            
            if (result.sfToken && result.sfInstanceUrl) {
                // Verify the token is still valid by making a test call
                try {
                    const response = await fetch(`${result.sfInstanceUrl}/services/data/v57.0/sobjects/`, {
                        headers: {
                            'Authorization': `Bearer ${result.sfToken}`,
                            'Content-Type': 'application/json'
                        }
                    });
                    
                    if (response.ok) {
                        this.isAuthenticated = true;
                        this.updateConnectivityIndicator('connected');
                        return;
                    } else {
                        // Token might be expired, try to re-authenticate
                        throw new Error('Token validation failed');
                    }
                } catch (error) {
                    console.log('Token validation failed, attempting re-authentication...');
                }
            }
            
            // If no stored credentials or validation failed, try to automatically authenticate
            const authResult = await chrome.runtime.sendMessage({action: 'authenticate'});
            
            if (authResult && authResult.success) {
                this.isAuthenticated = true;
                this.updateConnectivityIndicator('connected');
            } else {
                this.isAuthenticated = false;
                this.updateConnectivityIndicator('disconnected');
            }
            
        } catch (error) {
            console.error('Error checking auth status:', error);
            this.isAuthenticated = false;
            this.updateConnectivityIndicator('disconnected');
        }
        // Show modal if not connected
        this.checkOrgConnectionAndShowModal();
    }
    
    showNoConnectionModal() {
        let modal = document.getElementById('noConnectionModal');
        if (modal) modal.remove();
        modal = document.createElement('div');
        modal.id = 'noConnectionModal';
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100vw';
        modal.style.height = '100vh';
        modal.style.background = 'rgba(255,255,255)';
        modal.style.zIndex = '9999';
        modal.style.display = 'flex';
        modal.style.flexDirection = 'column';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.innerHTML = `
            <div style="text-align:center;">
                <div style="margin-bottom:32px;">
                    <svg width="120" height="90" viewBox="0 0 120 90">
                        <ellipse cx="60" cy="50" rx="40" ry="25" fill="#f3f4f6" />
                        <rect x="50" y="60" width="20" height="10" rx="5" fill="#f3f4f6" />
                        <polygon points="60,65 65,80 55,80" fill="#ff6b81" />
                    </svg>
                </div>
                <h2 style="font-size:2rem;font-weight:600;margin-bottom:12px;">Whoops!!</h2>
                <div style="font-size:1.1rem;color:#444;margin-bottom:18px;">No Salesforce Org Found. Please login your Salesforce Org.</div>
            </div>
        `;
        document.body.appendChild(modal);
        document.getElementById('loginSalesforceBtn').onclick = () => {
            window.location.reload();
        };
    }
    
    checkOrgConnectionAndShowModal() {
        if (!this.isAuthenticated) {
            this.showNoConnectionModal();
        } else {
            const modal = document.getElementById('noConnectionModal');
            if (modal) modal.remove();
        }
    }
    
    updateConnectivityIndicator(status) {
        const indicator = document.getElementById('connectivityIndicator');
        const dot = document.getElementById('connectivityDot');
        const text = document.getElementById('connectivityText');
        const pulse = document.getElementById('connectivityPulse');
        
        if (!indicator || !dot || !text || !pulse) return;
        
        // Reset all classes
        indicator.className = 'connectivity-indicator';
        dot.className = 'connectivity-dot';
        pulse.className = 'connectivity-pulse';
        
        switch (status) {
            case 'connected':
                indicator.classList.add('connected');
                dot.classList.add('connected');
                pulse.classList.add('connected', 'active');
                text.textContent = 'Connected';
                break;
                
            case 'disconnected':
                indicator.classList.add('disconnected');
                dot.classList.add('disconnected');
                pulse.classList.add('disconnected', 'active');
                text.textContent = 'Disconnected';
                break;
                
            case 'connecting':
                indicator.classList.add('connecting');
                dot.classList.add('connecting');
                pulse.classList.add('connecting', 'active');
                text.textContent = 'Connecting...';
                break;
                
            default:
                text.textContent = 'Unknown';
        }
    }
    
    updateConnectionStatus(status = null, message = null) {
        // Legacy method - redirect to new connectivity indicator
        if (status === 'authenticating') {
            this.updateConnectivityIndicator('connecting');
        } else if (this.isAuthenticated) {
            this.updateConnectivityIndicator('connected');
        } else {
            this.updateConnectivityIndicator('disconnected');
        }
    }
    
    updateUI() {
        const addEntryBtn = document.getElementById('addEntry');
        const bulkActions = document.getElementById('bulkActions');
        const recordCount = document.getElementById('recordCount');
        
        // Enable/disable add entry button - require both object and record type
        addEntryBtn.disabled = !this.selectedObject || !this.selectedRecordType;
        
        // Show/hide bulk actions
        if (this.entries.length > 0) {
            bulkActions.style.display = 'flex';
            recordCount.textContent = this.entries.length;
        } else {
            bulkActions.style.display = 'none';
        }
        
        // Update no entries message
        const noEntries = document.querySelector('.no-entries');
        if (this.entries.length === 0) {
            noEntries.style.display = 'block';
        } else {
            noEntries.style.display = 'none';
        }
    }
    
    addNewEntry() {
        if (!this.selectedObject || !this.selectedRecordType) return;
        
        this.entryCounter++;
        const entryId = `entry_${this.entryCounter}`;
        
        const entry = {
            id: entryId,
            objectType: this.selectedObject,
            recordType: this.selectedRecordType,
            data: {},
            status: 'draft',
            collapsed: false
        };
        
        this.entries.push(entry);
        this.renderEntry(entry);
        this.updateUI();
    }
    
    renderEntry(entry) {
        const template = document.getElementById('entryTemplate');
        const clone = template.content.cloneNode(true);
        
        const entryCard = clone.querySelector('.entry-card');
        entryCard.dataset.entryId = entry.id;
        
        // Update entry header
        clone.querySelector('.object-type').textContent = entry.objectType;
        clone.querySelector('.entry-status').textContent = this.getStatusText(entry.status);
        clone.querySelector('.entry-status').className = `entry-status ${entry.status}`;
        
        // Add title attribute to header for accessibility
        const header = clone.querySelector('.entry-header');
        header.setAttribute('title', 'Click to collapse/expand this entry');
        
        // Generate form fields
        const formFields = clone.querySelector('#formFields');
        formFields.innerHTML = this.generateFormFields(entry.objectType);
        
        // Insert into container
        const container = document.getElementById('entriesContainer');
        container.appendChild(clone);
        
        // Populate existing data if any
        this.populateFormData(entry);
    }
    
    generateFormFields(objectType) {
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        
        return fields.map(field => {
            const requiredClass = field.required ? 'required' : '';
            const fieldId = `${objectType}_${field.name}_${Date.now()}`;
            const placeholderText = this.getPlaceholderText(field);
            
            let input = '';
            if (field.type === 'select' && field.options) {
                const options = field.options.map(option => 
                    `<option value="${option}">${option}</option>`
                ).join('');
                input = `
                    <select name="${field.name}" id="${fieldId}">
                        <option value="">Select ${field.label}</option>
                        ${options}
                    </select>
                `;
            } else if (field.type === 'textarea') {
                input = `
                    <textarea name="${field.name}" id="${fieldId}" placeholder="${placeholderText}" rows="3"></textarea>
                `;
            } else if (field.type === 'checkbox') {
                input = `
                    <div class="checkbox-wrapper">
                        <input type="checkbox" name="${field.name}" id="${fieldId}">
                        <label for="${fieldId}" class="checkbox-label">${field.label}</label>
                    </div>
                `;
            } else {
                const inputType = field.type === 'text' ? 'text' : field.type;
                input = `
                    <input type="${inputType}" 
                           name="${field.name}" 
                           id="${fieldId}" 
                           placeholder="${placeholderText}"
                           ${field.type === 'number' ? 'step="any"' : ''}
                           ${field.required ? 'required' : ''}>
                `;
            }
            
            // Don't wrap checkbox fields in the standard form-group
            if (field.type === 'checkbox') {
                return `
                    <div class="form-group checkbox-group">
                        ${input}
                    </div>
                `;
            }
            
            return `
                <div class="form-group" data-field-type="${field.type}">
                    <label for="${fieldId}" class="${requiredClass}">${field.label}</label>
                    ${input}
                    <div class="field-feedback"></div>
                </div>
            `;
        }).join('');
    }
    
    getPlaceholderText(field) {
        const placeholders = {
            'email': 'Enter email address',
            'tel': 'Enter phone number',
            'url': 'Enter website URL',
            'date': 'Select date',
            'datetime-local': 'Select date and time',
            'number': 'Enter number',
            'text': `Enter ${field.label.toLowerCase()}`,
            'textarea': `Enter ${field.label.toLowerCase()}`
        };
        
        return placeholders[field.type] || `Enter ${field.label.toLowerCase()}`;
    }
    
    populateFormData(entry) {
        const entryCard = document.querySelector(`[data-entry-id="${entry.id}"]`);
        if (!entryCard) return;
        
        Object.entries(entry.data).forEach(([fieldName, value]) => {
            const input = entryCard.querySelector(`[name="${fieldName}"]`);
            if (input) {
                input.value = value;
            }
        });
    }
    
    getStatusText(status) {
        const statusMap = {
            draft: 'Draft',
            submitted: 'Submitted',
            error: 'Error'
        };
        return statusMap[status] || 'Unknown';
    }
    
    toggleEntry(entryId) {
        const entry = this.entries.find(e => e.id === entryId);
        if (!entry) return;
        
        entry.collapsed = !entry.collapsed;
        
        const entryCard = document.querySelector(`[data-entry-id="${entryId}"]`);
        const content = entryCard.querySelector('.entry-content');
        const toggleBtn = entryCard.querySelector('.toggle-btn');
        const collapseIndicator = entryCard.querySelector('.collapse-indicator');
        
        if (entry.collapsed) {
            content.classList.add('collapsed');
            toggleBtn.classList.add('collapsed');
            if (collapseIndicator) {
                collapseIndicator.classList.add('collapsed');
            }
        } else {
            content.classList.remove('collapsed');
            toggleBtn.classList.remove('collapsed');
            if (collapseIndicator) {
                collapseIndicator.classList.remove('collapsed');
            }
        }
    }
    
    async deleteEntry(entryId) {
        const entry = this.entries.find(e => e.id === entryId);
        const entryName = entry?.name || 'this entry';
        
        const confirmed = await this.showConfirmationModal({
            type: 'danger',
            title: 'Delete Entry',
            message: `Are you sure you want to delete "${entryName}"? This action cannot be undone and all unsaved data will be lost.`,
            confirmText: 'Delete Entry',
            cancelText: 'Cancel'
        });
        
        if (!confirmed) return;
        
        this.entries = this.entries.filter(e => e.id !== entryId);
        
        const entryCard = document.querySelector(`[data-entry-id="${entryId}"]`);
        if (entryCard) {
            entryCard.remove();
        }
        
        this.updateUI();
    }
    
    resetEntry(entryId) {
        const entry = this.entries.find(e => e.id === entryId);
        if (!entry) return;
        
        entry.data = {};
        entry.status = 'draft';
        
        const entryCard = document.querySelector(`[data-entry-id="${entryId}"]`);
        const form = entryCard.querySelector('.form-grid');
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            input.value = '';
            input.classList.remove('error');
        });
        
        this.updateEntryStatus(entryId, 'draft');
    }
    
    async submitSingleRecord(entryId) {
        const entry = this.entries.find(e => e.id === entryId);
        if (!entry) return;
        
        // Collect form data
        const entryCard = document.querySelector(`[data-entry-id="${entryId}"]`);
        const submitBtn = entryCard.querySelector('[data-action="submit"]');
        const formData = this.collectFormData(entryCard, entry.objectType);
        
        // Validate required fields
        const validation = this.validateFormData(formData, entry.objectType);
        if (!validation.isValid) {
            this.showValidationErrors(entryCard, validation.errors);
            return;
        }
        
        entry.data = formData;
        
        // Store original button state
        const originalButtonHTML = submitBtn.innerHTML;
        const originalButtonDisabled = submitBtn.disabled;
        
        try {
            // Show spinner and disable button
            submitBtn.innerHTML = `
                <div class="spinner"></div>
                Submitting...
            `;
            submitBtn.disabled = true;
            
            this.updateEntryStatus(entryId, 'submitting');
            
            // Submit to Salesforce
            const response = await this.submitToSalesforce(entry.objectType, formData, entry.recordType);
            
            // Add to recent records
            this.addRecentRecord({
                id: response.id,
                objectType: entry.objectType,
                recordType: entry.recordType,
                data: formData
            });
            
            // Show success state
            submitBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.061L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                </svg>
                Submitted!
            `;
            submitBtn.classList.add('success');
            
            this.updateEntryStatus(entryId, 'submitted');
            this.showSuccessMessage(entryCard, 'Record submitted successfully!');
            
            // Restore button after 3 seconds
            setTimeout(() => {
                submitBtn.innerHTML = originalButtonHTML;
                submitBtn.disabled = originalButtonDisabled;
                submitBtn.classList.remove('success');
            }, 3000);
            
        } catch (error) {
            console.error('Error submitting record:', error);
            
            // Show error state
            submitBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                </svg>
                Failed
            `;
            submitBtn.classList.add('error');
            
            this.updateEntryStatus(entryId, 'error');
            this.showErrorMessage(entryCard, 'Failed to submit record: ' + error.message);
            
            // Restore button after 5 seconds
            setTimeout(() => {
                submitBtn.innerHTML = originalButtonHTML;
                submitBtn.disabled = originalButtonDisabled;
                submitBtn.classList.remove('error');
            }, 5000);
        }
    }
    
    async submitAllRecords() {
        const confirmed = await this.showConfirmationModal({
            type: 'submit',
            title: 'Submit All Records',
            message: `Are you sure you want to submit all ${this.entries.length} records to Salesforce? This action cannot be undone.`,
            confirmText: `Submit ${this.entries.length} Records`,
            cancelText: 'Cancel'
        });
        
        if (!confirmed) return;
        
        const submitAllBtn = document.getElementById('submitAll');
        const originalText = submitAllBtn.textContent;
        submitAllBtn.innerHTML = '<span class="spinner"></span>Submitting...';
        submitAllBtn.disabled = true;
        
        let successCount = 0;
        let errorCount = 0;
        
        for (const entry of this.entries) {
            try {
                const entryCard = document.querySelector(`[data-entry-id="${entry.id}"]`);
                const formData = this.collectFormData(entryCard, entry.objectType);
                
                const validation = this.validateFormData(formData, entry.objectType);
                if (!validation.isValid) {
                    this.showValidationErrors(entryCard, validation.errors);
                    errorCount++;
                    continue;
                }
                
                this.updateEntryStatus(entry.id, 'submitting');
                const response = await this.submitToSalesforce(entry.objectType, formData, entry.recordType);
                
                // Add to recent records
                this.addRecentRecord({
                    id: response.id,
                    objectType: entry.objectType,
                    recordType: entry.recordType,
                    data: formData
                });
                
                this.updateEntryStatus(entry.id, 'submitted');
                successCount++;
                
            } catch (error) {
                console.error('Error submitting record:', error);
                this.updateEntryStatus(entry.id, 'error');
                errorCount++;
            }
        }
        
        submitAllBtn.innerHTML = originalText;
        submitAllBtn.disabled = false;
        
        // Show enhanced success/error message instead of alert
        if (errorCount === 0) {
            submitAllBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.061L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                </svg>
                All Submitted!
            `;
            submitAllBtn.classList.add('success');
            this.showGlobalMessage(`🎉 All ${successCount} records submitted successfully!`, 'success');
        } else if (successCount === 0) {
            submitAllBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                </svg>
                All Failed
            `;
            submitAllBtn.classList.add('error');
            this.showGlobalMessage(`❌ All ${errorCount} records failed to submit. Please check the errors above.`, 'error');
        } else {
            this.showGlobalMessage(`⚠️ Submission completed with mixed results: ${successCount} successful, ${errorCount} failed.`, 'warning');
        }
        
        // Restore button after 5 seconds
        setTimeout(() => {
            submitAllBtn.innerHTML = originalText;
            submitAllBtn.classList.remove('success', 'error');
        }, 5000);
    }
    
    collectFormData(entryCard, objectType) {
        const formData = {};
        const inputs = entryCard.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            const fieldName = input.name;
            let value = input.value;
            
            if (fieldName) {
                switch (input.type) {
                    case 'checkbox':
                        formData[fieldName] = input.checked;
                        break;
                    case 'number':
                        formData[fieldName] = value.trim();
                        break;
                    case 'date':
                    case 'datetime-local':
                        formData[fieldName] = value;
                        break;
                    default:
                        formData[fieldName] = value.trim();
                }
            }
        });
        
        return formData;
    }
    
    validateFormData(formData, objectType) {
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        const errors = {};
        let isValid = true;
        
        fields.forEach(field => {
            if (field.required && (!formData[field.name] || formData[field.name].trim() === '')) {
                errors[field.name] = `${field.label} is required`;
                isValid = false;
            }
            
            // Email validation
            if (field.type === 'email' && formData[field.name]) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(formData[field.name])) {
                    errors[field.name] = 'Please enter a valid email address';
                    isValid = false;
                }
            }
            
            // URL validation
            if (field.type === 'url' && formData[field.name]) {
                try {
                    new URL(formData[field.name]);
                } catch {
                    errors[field.name] = 'Please enter a valid URL';
                    isValid = false;
                }
            }
        });
        
        return { isValid, errors };
    }
    
    showValidationErrors(entryCard, errors) {
        // Clear previous errors
        entryCard.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
        entryCard.querySelectorAll('.error-message').forEach(el => el.remove());
        
        Object.entries(errors).forEach(([fieldName, message]) => {
            const input = entryCard.querySelector(`[name="${fieldName}"]`);
            if (input) {
                input.classList.add('error');
                
                const errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                errorDiv.textContent = message;
                input.parentNode.appendChild(errorDiv);
            }
        });
    }
    
    showSuccess(entryCard, message) {
        this.showMessage(entryCard, message, 'success');
    }
    
    showError(entryCard, message) {
        this.showMessage(entryCard, message, 'error');
    }
    
    // Enhanced message functions with better styling and auto-hide
    showSuccessMessage(entryCard, message) {
        this.showEnhancedMessage(entryCard, message, 'success');
    }
    
    showErrorMessage(entryCard, message) {
        this.showEnhancedMessage(entryCard, message, 'error');
    }
    
    showEnhancedMessage(entryCard, message, type) {
        // Remove existing messages
        entryCard.querySelectorAll('.enhanced-message').forEach(el => el.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `enhanced-message ${type}`;
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-icon">
                    ${type === 'success' ? 
                        '<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm0 1A8 8 0 1 0 10 0a8 8 0 0 0 0 16z"/><path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z" clip-rule="evenodd"/></svg>' :
                        '<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 0 1-2 0zm1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>'
                    }
                </div>
                <span class="message-text">${message}</span>
            </div>
        `;
        
        // Enhanced styling
        messageDiv.style.cssText = `
            display: flex;
            align-items: center;
            padding: 12px 16px;
            margin: 12px 0;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            animation: slideIn 0.3s ease-out;
            background: ${type === 'success' ? 
                'linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%)' : 
                'linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%)'
            };
            color: ${type === 'success' ? '#155724' : '#721c24'};
            border: 1px solid ${type === 'success' ? '#c3e6cb' : '#f5c6cb'};
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        `;
        
        const footer = entryCard.querySelector('.entry-footer');
        footer.parentNode.insertBefore(messageDiv, footer);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    if (messageDiv.parentNode) {
                        messageDiv.remove();
                    }
                }, 300);
            }
        }, 5000);
    }
    
    // Global message function for page-level notifications
    showGlobalMessage(message, type = 'info') {
        // Remove existing global messages
        document.querySelectorAll('.global-message').forEach(el => el.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `global-message ${type}`;
        messageDiv.innerHTML = `
            <div class="global-message-content">
                <span class="global-message-text">${message}</span>
                <button class="global-message-close" onclick="this.parentElement.parentElement.remove()">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M12.854 4.854a.5.5 0 0 0-.708-.708L8 8.293 3.854 4.146a.5.5 0 1 0-.708.708L7.293 9l-4.147 4.146a.5.5 0 0 0 .708.708L8 9.707l4.146 4.147a.5.5 0 0 0 .708-.708L8.707 9l4.147-4.146z"/>
                    </svg>
                </button>
            </div>
        `;
        
        // Style the message
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10000;
            min-width: 300px;
            max-width: 600px;
            padding: 16px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            animation: slideInFromTop 0.4s ease-out;
            background: ${type === 'success' ? 
                'linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%)' : 
                type === 'error' ? 
                'linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%)' :
                'linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%)'
            };
            color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#856404'};
            border: 1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : '#ffeaa7'};
        `;
        
        document.body.appendChild(messageDiv);
        
        // Auto-hide after 8 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.style.animation = 'slideOutToTop 0.4s ease-in';
                setTimeout(() => {
                    if (messageDiv.parentNode) {
                        messageDiv.remove();
                    }
                }, 400);
            }
        }, 8000);
    }
    
    showMessage(entryCard, message, type) {
        // Remove existing messages
        entryCard.querySelectorAll('.message').forEach(el => el.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        messageDiv.style.padding = '10px';
        messageDiv.style.margin = '10px 0';
        messageDiv.style.borderRadius = '4px';
        messageDiv.style.backgroundColor = type === 'success' ? '#d4edda' : '#f8d7da';
        messageDiv.style.color = type === 'success' ? '#155724' : '#721c24';
        messageDiv.style.border = `1px solid ${type === 'success' ? '#c3e6cb' : '#f5c6cb'}`;
        
        const footer = entryCard.querySelector('.entry-footer');
        footer.parentNode.insertBefore(messageDiv, footer);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }
    
    updateEntryStatus(entryId, status) {
        const entry = this.entries.find(e => e.id === entryId);
        if (entry) {
            entry.status = status;
        }
        
        const entryCard = document.querySelector(`[data-entry-id="${entryId}"]`);
        if (entryCard) {
            const statusElement = entryCard.querySelector('.entry-status');
            statusElement.textContent = this.getStatusText(status);
            statusElement.className = `entry-status ${status}`;
        }
    }
    
    async submitToSalesforce(objectType, data, recordTypeId) {
        if (!this.isAuthenticated) {
            throw new Error('Not authenticated with Salesforce');
        }
        
        const { sfToken, sfInstanceUrl } = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
        
        // Clean and format the data for Salesforce
        const cleanData = this.formatDataForSalesforce(data, objectType, recordTypeId);
        
        console.log('Submitting data to Salesforce:', cleanData);
        
        const response = await fetch(`${sfInstanceUrl}/services/data/v59.0/sobjects/${objectType}/`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${sfToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(cleanData)
        });
        
        if (!response.ok) {
            const errorResponse = await response.json();
            console.error('Salesforce API Error:', errorResponse);
            
            // Extract more detailed error information
            let errorMessage = 'Failed to create record';
            if (errorResponse.length > 0 && errorResponse[0].message) {
                errorMessage = errorResponse[0].message;
                if (errorResponse[0].fields && errorResponse[0].fields.length > 0) {
                    errorMessage += ` (Fields: ${errorResponse[0].fields.join(', ')})`;
                }
            } else if (errorResponse.message) {
                errorMessage = errorResponse.message;
            }
            
            throw new Error(errorMessage);
        }
        
        return await response.json();
    }
    
    formatDataForSalesforce(data, objectType, recordTypeId) {
        const cleanData = {};
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        
        // Add record type if provided
        if (recordTypeId && recordTypeId !== '012000000000000AAA') {
            cleanData.RecordTypeId = recordTypeId;
        }
        
        // Only include fields that are defined for this object type
        fields.forEach(field => {
            if (data[field.name] !== undefined && data[field.name] !== null) {
                let value = data[field.name];
                
                // Handle different field types
                switch (field.type) {
                    case 'checkbox':
                        cleanData[field.name] = value === true || value === 'true' || value === 'on';
                        break;
                    case 'number':
                        if (value !== '' && !isNaN(value)) {
                            cleanData[field.name] = parseFloat(value);
                        }
                        break;
                    case 'date':
                        if (value && value !== '') {
                            // Ensure date is in proper format for Salesforce
                            const date = new Date(value);
                            if (!isNaN(date.getTime())) {
                                cleanData[field.name] = date.toISOString().split('T')[0];
                            }
                        }
                        break;
                    case 'datetime-local':
                        if (value && value !== '') {
                            const date = new Date(value);
                            if (!isNaN(date.getTime())) {
                                cleanData[field.name] = date.toISOString();
                            }
                        }
                        break;
                    default:
                        // For text, email, tel, url, textarea, select
                        if (value && value.trim() !== '') {
                            cleanData[field.name] = value.trim();
                        }
                }
            }
        });
        
        return cleanData;
    }
    
    // Recent Records Sidebar Methods
    toggleSidebar() {
        if (this.sidebarOpen) {
            this.closeSidebar();
        } else {
            this.openSidebar();
        }
    }
    
    openSidebar() {
        const sidebar = document.getElementById('recentRecordsSidebar');
        const container = document.querySelector('.container');
        const toggleBtn = document.getElementById('sidebarToggleBtn');
        
        if (sidebar) {
            sidebar.classList.add('open');
            this.sidebarOpen = true;
            
            // Update floating button state
            if (toggleBtn) {
                toggleBtn.classList.add('sidebar-open');
                const icon = toggleBtn.querySelector('.sidebar-toggle-icon');
                if (icon) {
                    icon.innerHTML = `
                        <path d="M12.854 4.854a.5.5 0 0 0-.708-.708L8 8.293 3.854 4.146a.5.5 0 1 0-.708.708L7.293 9l-4.147 4.146a.5.5 0 0 0 .708.708L8 9.707l4.146 4.147a.5.5 0 0 0 .708-.708L8.707 9l4.147-4.146z"/>
                    `;
                }
            }
            
            // Add class to container for mobile responsiveness
            if (container && window.innerWidth <= 768) {
                container.classList.add('sidebar-open');
            }
        }
    }
    
    closeSidebar() {
        const sidebar = document.getElementById('recentRecordsSidebar');
        const container = document.querySelector('.container');
        const toggleBtn = document.getElementById('sidebarToggleBtn');
        
        if (sidebar) {
            sidebar.classList.remove('open');
            this.sidebarOpen = false;
            
            // Update floating button state
            if (toggleBtn) {
                toggleBtn.classList.remove('sidebar-open');
                const icon = toggleBtn.querySelector('.sidebar-toggle-icon');
                if (icon) {
                    icon.innerHTML = `
                        <path d="M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71V3.5z"/>
                        <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm7-8A7 7 0 1 1 1 8a7 7 0 0 1 14 0z"/>
                    `;
                }
            }
            
            // Remove class from container
            if (container) {
                container.classList.remove('sidebar-open');
            }
        }
    }
    
    addRecentRecord(recordData) {
        const recentRecord = {
            id: recordData.id,
            objectType: recordData.objectType,
            recordType: recordData.recordType,
            data: recordData.data,
            timestamp: new Date().toISOString(),
            displayName: this.generateRecordDisplayName(recordData)
        };
        
        // Add to beginning of array (most recent first)
        this.recentRecords.unshift(recentRecord);
        
        // Keep only last 50 records
        if (this.recentRecords.length > 50) {
            this.recentRecords = this.recentRecords.slice(0, 50);
        }
        
        // Update sidebar display
        this.updateRecentRecordsList();
        
        // Show and update the floating button
        this.updateFloatingButton();
        
        // Auto-open sidebar to show the new record
        this.openSidebar();
        
        // Save to local storage
        this.saveRecentRecordsToStorage();
    }
    
    generateRecordDisplayName(recordData) {
        const data = recordData.data;
        
        // Try common name fields first
        const nameFields = ['Name', 'FirstName', 'LastName', 'Company', 'Subject', 'Title'];
        
        for (const field of nameFields) {
            if (data[field] && data[field].trim()) {
                if (field === 'FirstName' && data['LastName']) {
                    return `${data['FirstName']} ${data['LastName']}`.trim();
                }
                return data[field].trim();
            }
        }
        
        // If no name field found, use object type
        return `New ${recordData.objectType} Record`;
    }
    
    updateRecentRecordsList() {
        const listContainer = document.getElementById('recentRecordsList');
        if (!listContainer) return;
        
        if (this.recentRecords.length === 0) {
            listContainer.innerHTML = `
                <div class="no-recent-records">
                    <svg width="48" height="48" viewBox="0 0 16 16" fill="currentColor" opacity="0.3">
                        <path d="M1 2.5A1.5 1.5 0 0 1 2.5 1h3A1.5 1.5 0 0 1 7 2.5v3A1.5 1.5 0 0 1 5.5 7h-3A1.5 1.5 0 0 1 1 5.5v-3zM2.5 2a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zm6.5.5A1.5 1.5 0 0 1 10.5 1h3A1.5 1.5 0 0 1 15 2.5v3A1.5 1.5 0 0 1 13.5 7h-3A1.5 1.5 0 0 1 9 5.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zM1 10.5A1.5 1.5 0 0 1 2.5 9h3A1.5 1.5 0 0 1 7 10.5v3A1.5 1.5 0 0 1 5.5 15h-3A1.5 1.5 0 0 1 1 13.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zm6.5.5A1.5 1.5 0 0 1 10.5 9h3a1.5 1.5 0 0 1 1.5 1.5v3a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 13.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3z"/>
                    </svg>
                    <p>No recent records yet</p>
                    <span>Successfully created records will appear here</span>
                </div>
            `;
            return;
        }
        
        const html = this.recentRecords.map((record, index) => {
            const timeAgo = this.formatTimeAgo(new Date(record.timestamp));
            const objectIcon = this.getObjectIcon(record.objectType);
            
            return `
                <div class="recent-record-item ${index === 0 ? 'new' : ''}" data-record-id="${record.id}">
                    <div class="recent-record-header">
                        <div class="recent-record-type">
                            <div class="recent-record-icon" style="background-color: ${objectIcon}">
                                ${record.objectType.charAt(0)}
                            </div>
                            ${record.objectType}
                        </div>
                        <div class="recent-record-time">${timeAgo}</div>
                    </div>
                    <div class="recent-record-details">
                        ${record.displayName}
                    </div>
                    <div class="recent-record-success">
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                            <path d="M10.97 3.97a.235.235 0 0 0-.02.022L6.477 8.417 4.384 6.323a.75.75 0 0 0-1.06 1.061L5.97 10.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                        </svg>
                        Successfully created
                    </div>
                    <div class="recent-record-id">
                        <span class="recent-record-id-label">ID:</span>
                        <span class="recent-record-id-value">${record.id}</span>
                        <button class="copy-id-btn" onclick="navigator.clipboard.writeText('${record.id}'); this.innerHTML='<svg width=14 height=14 viewBox=\\'0 0 14 14\\' fill=\\'currentColor\\'><path d=\\'M10.97 3.97a.235.235 0 0 0-.02.022L6.477 8.417 4.384 6.323a.75.75 0 0 0-1.06 1.061L5.97 10.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z\\'/></svg>'; setTimeout(() => this.innerHTML='<svg width=14 height=14 viewBox=\\'0 0 14 14\\' fill=\\'currentColor\\'><path d=\\'M8 2a.5.5 0 0 1 .5.5V4H10a.5.5 0 0 1 0 1H8.5v1.5a.5.5 0 0 1-1 0V5H6a.5.5 0 0 1 0-1h1.5V2.5A.5.5 0 0 1 8 2z\\'/></svg>', 2000);">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                                <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
                                <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
        
        listContainer.innerHTML = html;
        
        // Add click handlers for record items
        listContainer.querySelectorAll('.recent-record-item').forEach(item => {
            item.addEventListener('click', (e) => {
                // Don't trigger if clicking on copy button
                if (!e.target.closest('.copy-id-btn')) {
                    const recordId = item.dataset.recordId;
                    const record = this.recentRecords.find(r => r.id === recordId);
                    if (record) {
                        this.showRecordDetails(record);
                    }
                }
            });
            
            // Add hover effect
            item.style.cursor = 'pointer';
        });
        
        // Add click animation to the newest item
        if (this.recentRecords.length > 0) {
            const newestItem = listContainer.querySelector('.recent-record-item.new');
            if (newestItem) {
                setTimeout(() => {
                    newestItem.classList.add('success-highlight');
                }, 100);
            }
        }
    }
    
    formatTimeAgo(date) {
        const now = new Date();
        const diffMs = now - date;
        const diffSecs = Math.floor(diffMs / 1000);
        const diffMins = Math.floor(diffSecs / 60);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffSecs < 60) {
            return 'Just now';
        } else if (diffMins < 60) {
            return `${diffMins}m ago`;
        } else if (diffHours < 24) {
            return `${diffHours}h ago`;
        } else if (diffDays < 7) {
            return `${diffDays}d ago`;
        } else {
            return date.toLocaleDateString();
        }
    }
    
    clearRecentRecords() {
        this.recentRecords = [];
        this.updateRecentRecordsList();
        this.updateFloatingButton();
        this.saveRecentRecordsToStorage();
    }
    
    updateFloatingButton() {
        const toggleBtn = document.getElementById('sidebarToggleBtn');
        const countElement = document.getElementById('sidebarToggleCount');
        
        if (!toggleBtn || !countElement) return;
        
        const recordCount = this.recentRecords.length;
        
        if (recordCount > 0) {
            // Show the button
            toggleBtn.classList.add('visible');
            
            // Update count with animation
            const currentCount = parseInt(countElement.textContent) || 0;
            if (recordCount !== currentCount) {
                countElement.textContent = recordCount > 99 ? '99+' : recordCount.toString();
                countElement.classList.add('updated');
                
                // Remove animation class after animation completes
                setTimeout(() => {
                    countElement.classList.remove('updated');
                }, 400);
            }
        } else {
            // Hide the button
            toggleBtn.classList.remove('visible');
            countElement.textContent = '0';
        }
    }
    
    // Record Details Modal Methods
    showRecordDetails(record) {
        this.currentEditingRecord = record;
        this.originalRecordData = { ...record.data };
        
        const modal = document.getElementById('recordDetailsModal');
        const title = document.getElementById('recordDetailsTitle');
        const metadata = document.getElementById('recordMetadata');
        const fields = document.getElementById('recordFields');
        
        // Update modal title
        if (title) {
            const titleText = title.querySelector('svg').nextSibling;
            titleText.textContent = ` ${record.objectType} - ${record.displayName}`;
        }
        
        // Populate metadata
        if (metadata) {
            metadata.innerHTML = `
                <div class="record-metadata-item">
                    <div class="record-metadata-label">Salesforce ID</div>
                    <div class="record-metadata-value">${record.id}</div>
                </div>
                <div class="record-metadata-item">
                    <div class="record-metadata-label">Object Type</div>
                    <div class="record-metadata-value">${record.objectType}</div>
                </div>
                <div class="record-metadata-item">
                    <div class="record-metadata-label">Record Type</div>
                    <div class="record-metadata-value">${record.recordType || 'Default'}</div>
                </div>
                <div class="record-metadata-item">
                    <div class="record-metadata-label">Created</div>
                    <div class="record-metadata-value">${this.formatTimestamp(record.timestamp)}</div>
                </div>
            `;
        }
        
        // Populate fields
        if (fields) {
            const fieldsHtml = Object.entries(record.data).map(([fieldName, value]) => {
                // Get field info for proper display formatting
                const fieldInfo = this.getFieldType(record.objectType, fieldName);
                
                // Format display value based on field type
                let displayValue = '';
                let isEmpty = false;
                
                if (fieldInfo.type === 'checkbox') {
                    displayValue = value ? 'Yes' : 'No';
                    isEmpty = false; // Checkboxes always have a value
                } else if (fieldInfo.type === 'date' && value) {
                    // Format date for display
                    try {
                        const date = new Date(value);
                        displayValue = date.toLocaleDateString();
                    } catch {
                        displayValue = value;
                    }
                } else if (fieldInfo.type === 'datetime-local' && value) {
                    // Format datetime for display
                    try {
                        const date = new Date(value);
                        displayValue = date.toLocaleString();
                    } catch {
                        displayValue = value;
                    }
                } else {
                    isEmpty = !value || value.toString().trim() === '';
                    displayValue = isEmpty ? '(No value)' : value;
                }
                
                return `
                    <div class="record-field-item" data-field-name="${fieldName}">
                        <div class="record-field-label">${this.getFieldLabel(record.objectType, fieldName)}</div>
                        <div class="record-field-value ${isEmpty ? 'empty' : ''}" data-original-value="${value || ''}">
                            ${displayValue}
                        </div>
                        <div class="record-field-actions">
                            <button class="field-edit-btn" title="Edit field">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                                    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61z"/>
                                    <path d="M11.5 6.366l-1.732-1.732"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
            
            fields.innerHTML = fieldsHtml;
            
            // Add field edit handlers
            fields.querySelectorAll('.field-edit-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.enableFieldEditing(btn.closest('.record-field-item'));
                });
            });
        }
        
        // Show modal
        if (modal) {
            modal.classList.add('show');
        }
        
        // Reset edit mode
        this.exitEditMode();
    }
    
    closeRecordDetailsModal() {
        const modal = document.getElementById('recordDetailsModal');
        if (modal) {
            modal.classList.remove('show');
        }
        
        this.currentEditingRecord = null;
        this.originalRecordData = {};
        this.exitEditMode();
    }
    
    enableRecordEditing() {
        const editBtn = document.getElementById('recordDetailsEdit');
        const saveBtn = document.getElementById('recordDetailsSave');
        const fields = document.getElementById('recordFields');
        
        // Switch button visibility
        if (editBtn) editBtn.style.display = 'none';
        if (saveBtn) saveBtn.style.display = 'flex';
        
        // Enable all field editing
        if (fields) {
            fields.querySelectorAll('.record-field-item').forEach(item => {
                this.enableFieldEditing(item);
            });
        }
    }
    
    enableFieldEditing(fieldItem) {
        const valueElement = fieldItem.querySelector('.record-field-value');
        const actionsElement = fieldItem.querySelector('.record-field-actions');
        const fieldName = fieldItem.dataset.fieldName;
        const currentValue = valueElement.dataset.originalValue || '';
        
        // Get detailed field information
        const fieldInfo = this.getFieldType(this.currentEditingRecord.objectType, fieldName);
        const inputAttrs = this.getInputAttributes(fieldInfo, currentValue);
        
        // Create appropriate input element based on field type
        let inputHtml = '';
        
        if (fieldInfo.type === 'textarea') {
            inputHtml = `<textarea class="record-field-input${inputAttrs.required ? ' required' : ''}" 
                         rows="${inputAttrs.rows}" 
                         placeholder="${inputAttrs.placeholder}"
                         ${inputAttrs.required ? 'required' : ''}>${currentValue}</textarea>`;
        } 
        else if (fieldInfo.type === 'select' && fieldInfo.options && fieldInfo.options.length > 0) {
            const optionsHtml = fieldInfo.options.map(opt => 
                `<option value="${opt}" ${opt === currentValue ? 'selected' : ''}>${opt}</option>`
            ).join('');
            inputHtml = `
                <select class="record-field-input${inputAttrs.required ? ' required' : ''}" 
                        ${inputAttrs.required ? 'required' : ''}>
                    <option value="">Select ${fieldInfo.label}...</option>
                    ${optionsHtml}
                </select>
            `;
        }
        else if (fieldInfo.type === 'checkbox') {
            const isChecked = currentValue === 'true' || currentValue === true;
            inputHtml = `
                <div class="checkbox-wrapper">
                    <input type="checkbox" 
                           class="record-field-input checkbox-input" 
                           ${isChecked ? 'checked' : ''}
                           value="true">
                    <label class="checkbox-label">${fieldInfo.label}</label>
                </div>
            `;
        }
        else {
            // Handle all other input types (text, email, tel, url, number, date, datetime-local)
            const inputType = inputAttrs.type;
            let additionalAttrs = '';
            
            if (inputAttrs.pattern) additionalAttrs += ` pattern="${inputAttrs.pattern}"`;
            if (inputAttrs.step) additionalAttrs += ` step="${inputAttrs.step}"`;
            if (inputAttrs.required) additionalAttrs += ' required';
            
            inputHtml = `<input type="${inputType}" 
                         class="record-field-input${inputAttrs.required ? ' required' : ''}" 
                         value="${currentValue}" 
                         placeholder="${inputAttrs.placeholder}"
                         ${additionalAttrs}>`;
        }
        
        // Replace value element with input
        valueElement.outerHTML = inputHtml;
        
        // Update actions
        actionsElement.innerHTML = `
            <button class="field-save-btn" title="Save field">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M10.97 3.97a.235.235 0 0 0-.02.022L6.477 8.417 4.384 6.323a.75.75 0 0 0-1.06 1.061L5.97 10.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                </svg>
            </button>
            <button class="field-cancel-btn" title="Cancel">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M12.854 4.854a.5.5 0 0 0-.708-.708L7 9.293 1.854 4.146a.5.5 0 1 0-.708.708L6.293 10l-5.147 5.146a.5.5 0 0 0 .708.708L7 10.707l5.146 5.147a.5.5 0 0 0 .708-.708L7.707 10l5.147-5.146z"/>
                </svg>
            </button>
        `;
        
        // Add field-level action handlers
        const saveBtn = actionsElement.querySelector('.field-save-btn');
        const cancelBtn = actionsElement.querySelector('.field-cancel-btn');
        
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveFieldEdit(fieldItem));
        }
        
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.cancelFieldEdit(fieldItem));
        }
        
        // Mark as editing
        fieldItem.classList.add('editing');
        
        // Focus input and add field type class for styling
        const input = fieldItem.querySelector('.record-field-input');
        if (input) {
            // Add field type class for specific styling
            fieldItem.classList.add(`field-type-${fieldInfo.type}`);
            
            input.focus();
            if (input.type === 'text' || input.type === 'email' || input.type === 'tel' || input.type === 'url') {
                input.select();
            }
            
            // Add validation for specific field types
            this.addFieldValidation(input, fieldInfo);
        }
    }
    
    // Add field validation based on type
    addFieldValidation(input, fieldInfo) {
        input.addEventListener('blur', () => {
            this.validateField(input, fieldInfo);
        });
        
        input.addEventListener('input', () => {
            // Clear previous validation state on input
            input.classList.remove('invalid', 'valid');
            const fieldItem = input.closest('.record-field-item');
            if (fieldItem) {
                fieldItem.classList.remove('field-invalid');
            }
        });
    }
    
    validateField(input, fieldInfo) {
        const value = input.type === 'checkbox' ? input.checked : input.value;
        const fieldItem = input.closest('.record-field-item');
        let isValid = true;
        
        // Required field validation
        if (fieldInfo.required && (!value || value.toString().trim() === '')) {
            isValid = false;
        }
        
        // Type-specific validation
        if (value && value.toString().trim() !== '') {
            switch (fieldInfo.type) {
                case 'email':
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    isValid = emailRegex.test(value);
                    break;
                case 'url':
                    try {
                        new URL(value);
                    } catch {
                        isValid = false;
                    }
                    break;
                case 'tel':
                    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
                    isValid = phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''));
                    break;
                case 'number':
                    isValid = !isNaN(parseFloat(value)) && isFinite(value);
                    break;
                case 'date':
                    const dateValue = new Date(value);
                    isValid = !isNaN(dateValue.getTime());
                    break;
            }
        }
        
        // Apply validation styling
        if (isValid) {
            input.classList.remove('invalid');
            input.classList.add('valid');
            if (fieldItem) fieldItem.classList.remove('field-invalid');
        } else {
            input.classList.remove('valid');
            input.classList.add('invalid');
            if (fieldItem) fieldItem.classList.add('field-invalid');
        }
        
        return isValid;
    }
    
    saveFieldEdit(fieldItem) {
        const fieldName = fieldItem.dataset.fieldName;
        const input = fieldItem.querySelector('.record-field-input');
        
        // Get value based on input type
        let newValue = '';
        if (input) {
            if (input.type === 'checkbox') {
                newValue = input.checked;
            } else {
                newValue = input.value;
            }
        }
        
        // Validate field before saving
        const fieldInfo = this.getFieldType(this.currentEditingRecord.objectType, fieldName);
        const isValid = this.validateField(input, fieldInfo);
        
        if (!isValid) {
            // Show validation error - don't save
            input.focus();
            return;
        }
        
        // Update current record data
        this.currentEditingRecord.data[fieldName] = newValue;
        
        // Create display element
        let displayValue = '';
        let isEmpty = false;
        
        if (fieldInfo.type === 'checkbox') {
            displayValue = newValue ? 'Yes' : 'No';
            isEmpty = false; // Checkboxes always have a value
        } else {
            isEmpty = !newValue || newValue.toString().trim() === '';
            displayValue = isEmpty ? '(No value)' : newValue;
        }
        
        const valueHtml = `
            <div class="record-field-value ${isEmpty ? 'empty' : ''}" data-original-value="${newValue}">
                ${displayValue}
            </div>
        `;
        
        input.outerHTML = valueHtml;
        
        // Reset actions
        const actionsElement = fieldItem.querySelector('.record-field-actions');
        actionsElement.innerHTML = `
            <button class="field-edit-btn" title="Edit field">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61z"/>
                    <path d="M11.5 6.366l-1.732-1.732"/>
                </svg>
            </button>
        `;
        
        // Re-add edit handler
        const editBtn = actionsElement.querySelector('.field-edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.enableFieldEditing(fieldItem);
            });
        }
        
        // Remove editing state and field type classes, show saved state
        fieldItem.classList.remove('editing', 'field-invalid');
        fieldItem.className = fieldItem.className.replace(/field-type-\w+/g, '');
        fieldItem.classList.add('saved');
        
        setTimeout(() => {
            fieldItem.classList.remove('saved');
        }, 2000);
    }
    
    cancelFieldEdit(fieldItem) {
        const fieldName = fieldItem.dataset.fieldName;
        const originalValue = this.originalRecordData[fieldName];
        
        // Get field info for proper display formatting
        const fieldInfo = this.getFieldType(this.currentEditingRecord.objectType, fieldName);
        
        // Format display value based on field type
        let displayValue = '';
        let isEmpty = false;
        
        if (fieldInfo.type === 'checkbox') {
            displayValue = originalValue ? 'Yes' : 'No';
            isEmpty = false; // Checkboxes always have a value
        } else {
            isEmpty = !originalValue || originalValue.toString().trim() === '';
            displayValue = isEmpty ? '(No value)' : originalValue;
        }
        
        const input = fieldItem.querySelector('.record-field-input');
        const valueHtml = `
            <div class="record-field-value ${isEmpty ? 'empty' : ''}" data-original-value="${originalValue || ''}">
                ${displayValue}
            </div>
        `;
        
        input.outerHTML = valueHtml;
        
        // Reset actions
        const actionsElement = fieldItem.querySelector('.record-field-actions');
        actionsElement.innerHTML = `
            <button class="field-edit-btn" title="Edit field">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61z"/>
                    <path d="M11.5 6.366l-1.732-1.732"/>
                </svg>
            </button>
        `;
        
        // Re-add edit handler
        const editBtn = actionsElement.querySelector('.field-edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.enableFieldEditing(fieldItem);
            });
        }
        
        // Remove editing state and field type classes
        fieldItem.classList.remove('editing', 'field-invalid');
        fieldItem.className = fieldItem.className.replace(/field-type-\w+/g, '');
    }
    
    async saveRecordChanges() {
        const saveBtn = document.getElementById('recordDetailsSave');
        const originalText = saveBtn.innerHTML;
        
        try {
            // Show loading state
            saveBtn.innerHTML = `
                <div class="spinner"></div>
                Saving...
            `;
            saveBtn.disabled = true;
            
            // Update record in Salesforce
            await this.updateSalesforceRecord(this.currentEditingRecord);
            
            // Update the record in recent records
            const recordIndex = this.recentRecords.findIndex(r => r.id === this.currentEditingRecord.id);
            if (recordIndex !== -1) {
                this.recentRecords[recordIndex] = { ...this.currentEditingRecord };
                this.saveRecentRecordsToStorage();
                this.updateRecentRecordsList();
            }
            
            // Show success
            saveBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.061L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                </svg>
                Saved Successfully!
            `;
            
            setTimeout(() => {
                this.closeRecordDetailsModal();
            }, 1500);
            
        } catch (error) {
            console.error('Error saving record:', error);
            
            // Show error
            saveBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                </svg>
                Save Failed
            `;
            
            setTimeout(() => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
            }, 3000);
        }
    }
    
    exitEditMode() {
        const editBtn = document.getElementById('recordDetailsEdit');
        const saveBtn = document.getElementById('recordDetailsSave');
        
        if (editBtn) editBtn.style.display = 'flex';
        if (saveBtn) saveBtn.style.display = 'none';
    }
    
    // Helper methods for record details
    formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString();
    }
    
    getFieldLabel(objectType, fieldName) {
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        const field = fields.find(f => f.name === fieldName);
        return field ? field.label : fieldName;
    }
    
    getFieldType(objectType, fieldName) {
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        const field = fields.find(f => f.name === fieldName);
        if (!field) return 'text';
        
        // Return the actual Salesforce field data for more detailed type information
        return {
            type: field.type,
            options: field.options,
            required: field.required,
            label: field.label,
            name: field.name
        };
    }
    
    getFieldOptions(objectType, fieldName) {
        const fields = this.objectFields[objectType] || FALLBACK_OBJECTS[objectType] || [];
        const field = fields.find(f => f.name === fieldName);
        return field && field.options ? field.options : [];
    }
    
    mapFieldTypeToInput(fieldInfo) {
        if (typeof fieldInfo === 'string') {
            // Fallback for simple string types
            const typeMap = {
                'text': 'text',
                'email': 'email',
                'tel': 'tel',
                'url': 'url',
                'number': 'number',
                'date': 'date',
                'datetime-local': 'datetime-local',
                'checkbox': 'checkbox'
            };
            return typeMap[fieldInfo] || 'text';
        }
        
        // Enhanced mapping for detailed field information
        const typeMap = {
            'text': 'text',
            'email': 'email',
            'tel': 'tel',
            'url': 'url',
            'number': 'number',
            'date': 'date',
            'datetime-local': 'datetime-local',
            'checkbox': 'checkbox',
            'textarea': 'textarea',
            'select': 'select'
        };
        return typeMap[fieldInfo.type] || 'text';
    }
    
    // Enhanced method to determine appropriate input attributes
    getInputAttributes(fieldInfo, currentValue) {
        const attributes = {
            type: this.mapFieldTypeToInput(fieldInfo),
            value: currentValue || '',
            placeholder: `Enter ${fieldInfo.label || fieldInfo.name}`,
            required: fieldInfo.required || false
        };
        
        // Add specific attributes based on field type
        switch (fieldInfo.type) {
            case 'email':
                attributes.placeholder = 'Enter email address';
                break;
            case 'tel':
                attributes.placeholder = 'Enter phone number';
                attributes.pattern = '[0-9\\-\\+\\s\\(\\)]+';
                break;
            case 'url':
                attributes.placeholder = 'Enter URL (https://...)';
                break;
            case 'number':
                attributes.placeholder = 'Enter number';
                attributes.step = fieldInfo.name.toLowerCase().includes('percent') ? '0.01' : 'any';
                break;
            case 'date':
                attributes.placeholder = 'Select date';
                break;
            case 'datetime-local':
                attributes.placeholder = 'Select date and time';
                break;
            case 'textarea':
                attributes.rows = 3;
                attributes.placeholder = `Enter ${fieldInfo.label || fieldInfo.name}`;
                break;
        }
        
        return attributes;
    }
    
    async updateSalesforceRecord(record) {
        if (!this.isAuthenticated) {
            throw new Error('Not authenticated with Salesforce');
        }
        
        const { sfToken, sfInstanceUrl } = await chrome.storage.local.get(['sfToken', 'sfInstanceUrl']);
        
        // Format data for Salesforce update
        const updateData = this.formatDataForSalesforce(record.data, record.objectType, record.recordType);
        
        console.log('Updating record in Salesforce:', updateData);
        
        const response = await fetch(`${sfInstanceUrl}/services/data/v59.0/sobjects/${record.objectType}/${record.id}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${sfToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updateData)
        });
        
        if (!response.ok) {
            const errorResponse = await response.json();
            console.error('Salesforce Update Error:', errorResponse);
            
            let errorMessage = 'Failed to update record';
            if (errorResponse.length > 0 && errorResponse[0].message) {
                errorMessage = errorResponse[0].message;
            } else if (errorResponse.message) {
                errorMessage = errorResponse.message;
            }
            
            throw new Error(errorMessage);
        }
        
        return true;
    }
    
    saveRecentRecordsToStorage() {
        try {
            chrome.storage.local.set({
                recentRecords: this.recentRecords
            });
        } catch (error) {
            console.error('Error saving recent records:', error);
        }
    }
    
    async loadRecentRecordsFromStorage() {
        try {
            const result = await chrome.storage.local.get(['recentRecords']);
            if (result.recentRecords && Array.isArray(result.recentRecords)) {
                this.recentRecords = result.recentRecords;
                this.updateRecentRecordsList();
                this.updateFloatingButton();
            }
        } catch (error) {
            console.error('Error loading recent records:', error);
        }
    }
    
    async clearAllEntries() {
        const confirmed = await this.showConfirmationModal({
            type: 'danger',
            title: 'Delete All Entries',
            message: `Are you sure you want to delete all ${this.entries.length} entries? This action cannot be undone and all unsaved data will be lost.`,
            confirmText: 'Delete All',
            cancelText: 'Cancel'
        });
        
        if (!confirmed) return;
        
        this.entries = [];
        this.entryCounter = 0;
        
        const container = document.getElementById('entriesContainer');
        const entryCards = container.querySelectorAll('.entry-card');
        entryCards.forEach(card => card.remove());
        
        this.updateUI();
    }
    
    refreshData() {
        this.checkAuthStatus();
        
        // Reset objects and fields cache
        this.availableObjects = [];
        this.objectFields = {};
        
        // Reload current object if selected
        if (this.selectedObject) {
            this.loadObjectFields(this.selectedObject);
        }
        
        // Show refresh animation
        const refreshBtn = document.getElementById('refreshData');
        const originalContent = refreshBtn.innerHTML;
        refreshBtn.innerHTML = '<div class="spinner"></div>Refreshing...';
        refreshBtn.disabled = true;
        
        setTimeout(() => {
            refreshBtn.innerHTML = originalContent;
            refreshBtn.disabled = false;
        }, 1500);
    }
    
    setupFormValidation() {
        document.addEventListener('input', (e) => {
            if (e.target.matches('.form-group input, .form-group select, .form-group textarea')) {
                this.validateField(e.target);
            }
        });
        
        document.addEventListener('blur', (e) => {
            if (e.target.matches('.form-group input, .form-group select, .form-group textarea')) {
                this.validateField(e.target);
            }
        });
        
        // Add floating label effects
        document.addEventListener('focus', (e) => {
            if (e.target.matches('.form-group input, .form-group select, .form-group textarea')) {
                const formGroup = e.target.closest('.form-group');
                formGroup.classList.add('focused');
            }
        }, true);
        
        document.addEventListener('blur', (e) => {
            if (e.target.matches('.form-group input, .form-group select, .form-group textarea')) {
                const formGroup = e.target.closest('.form-group');
                formGroup.classList.remove('focused');
                if (!e.target.value) {
                    formGroup.classList.remove('has-value');
                }
            }
        }, true);
        
        // Handle input value changes for floating labels
        document.addEventListener('input', (e) => {
            if (e.target.matches('.form-group input, .form-group select, .form-group textarea')) {
                const formGroup = e.target.closest('.form-group');
                if (e.target.value) {
                    formGroup.classList.add('has-value');
                } else {
                    formGroup.classList.remove('has-value');
                }
            }
        });
    }
    
    validateField(field) {
        const formGroup = field.closest('.form-group');
        const feedback = formGroup.querySelector('.field-feedback');
        const isRequired = field.hasAttribute('required');
        const value = field.value.trim();
        
        // Reset states
        formGroup.classList.remove('field-error', 'field-success');
        feedback.textContent = '';
        
        // Check if required field is empty
        if (isRequired && !value) {
            this.showFieldError(formGroup, feedback, 'This field is required');
            return false;
        }
        
        // Skip further validation if field is empty and not required
        if (!value && !isRequired) {
            return true;
        }
        
        // Type-specific validation
        const fieldType = field.type;
        let isValid = true;
        let errorMessage = '';
        
        switch (fieldType) {
            case 'email':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Please enter a valid email address';
                }
                break;
                
            case 'tel':
                const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
                if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
                    isValid = false;
                    errorMessage = 'Please enter a valid phone number';
                }
                break;
                
            case 'url':
                try {
                    new URL(value);
                } catch {
                    isValid = false;
                    errorMessage = 'Please enter a valid URL';
                }
                break;
                
            case 'number':
                if (isNaN(value) || value === '') {
                    isValid = false;
                    errorMessage = 'Please enter a valid number';
                }
                break;
                
            case 'date':
                const dateValue = new Date(value);
                if (isNaN(dateValue.getTime())) {
                    isValid = false;
                    errorMessage = 'Please enter a valid date';
                }
                break;
        }
        
        if (!isValid) {
            this.showFieldError(formGroup, feedback, errorMessage);
            return false;
        } else {
            this.showFieldSuccess(formGroup);
            return true;
        }
    }
    
    showFieldError(formGroup, feedback, message) {
        formGroup.classList.add('field-error');
        formGroup.classList.remove('field-success');
        feedback.textContent = message;
        feedback.style.color = '#dc3545';
    }
    
    showFieldSuccess(formGroup) {
        formGroup.classList.add('field-success');
        formGroup.classList.remove('field-error');
        const feedback = formGroup.querySelector('.field-feedback');
        feedback.textContent = '';
    }
    
    // Custom Modal Methods
    showConfirmationModal(options) {
        return new Promise((resolve) => {
            const modal = document.getElementById('confirmationModal');
            const modalIcon = document.getElementById('modalIcon');
            const modalTitle = document.getElementById('modalTitle');
            const modalMessage = document.getElementById('modalMessage');
            const confirmBtn = document.getElementById('modalConfirm');
            const cancelBtn = document.getElementById('modalCancel');
            
            // Set modal content
            modalTitle.textContent = options.title || 'Confirm Action';
            modalMessage.textContent = options.message || 'Are you sure you want to proceed?';
            
            // Set icon and button style based on type
            modalIcon.className = 'modal-icon';
            confirmBtn.className = 'btn modal-btn-confirm';
            
            if (options.type === 'danger') {
                modalIcon.classList.add('danger');
                confirmBtn.classList.add('btn-danger');
                confirmBtn.textContent = options.confirmText || 'Delete';
                modalIcon.innerHTML = `
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/>
                    </svg>
                `;
            } else if (options.type === 'submit') {
                modalIcon.classList.add('warning');
                confirmBtn.classList.add('submit');
                confirmBtn.textContent = options.confirmText || 'Submit';
                modalIcon.innerHTML = `
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3"/>
                    </svg>
                `;
            } else {
                modalIcon.classList.add('warning');
                confirmBtn.textContent = options.confirmText || 'Confirm';
                modalIcon.innerHTML = `
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/>
                    </svg>
                `;
            }
            
            cancelBtn.textContent = options.cancelText || 'Cancel';
            
            // Show modal
            modal.classList.add('show');
            
            // Handle confirm
            const handleConfirm = () => {
                modal.classList.remove('show');
                cleanup();
                resolve(true);
            };
            
            // Handle cancel
            const handleCancel = () => {
                modal.classList.remove('show');
                cleanup();
                resolve(false);
            };
            
            // Handle escape key
            const handleEscape = (e) => {
                if (e.key === 'Escape') {
                    handleCancel();
                }
            };
            
            // Handle click outside modal
            const handleClickOutside = (e) => {
                if (e.target === modal) {
                    handleCancel();
                }
            };
            
            const cleanup = () => {
                confirmBtn.removeEventListener('click', handleConfirm);
                cancelBtn.removeEventListener('click', handleCancel);
                document.removeEventListener('keydown', handleEscape);
                modal.removeEventListener('click', handleClickOutside);
            };
            
            // Add event listeners
            confirmBtn.addEventListener('click', handleConfirm);
            cancelBtn.addEventListener('click', handleCancel);
            document.addEventListener('keydown', handleEscape);
            modal.addEventListener('click', handleClickOutside);
        });
    }
}

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SalesforceRecordManager();
});
